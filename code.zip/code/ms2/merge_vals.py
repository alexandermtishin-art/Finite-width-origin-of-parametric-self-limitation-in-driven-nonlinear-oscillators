import json
a=json.load(open('longtime_vals_auto.json'))
a['sm_quantum']=('The quantum long runs use the grid of the early-time calculations; for $ℏ_{eff}$ = 0.06 and 0.03, where $σ_{max}$ reaches its largest values, '
 'doubling $M$ and halving $Δt$ changes $σ_{max}$ by less than 1.1×10$^{−4}$ up to $t$ = 250. Table S8 lists the break times, the deviation at the first quantum maximum and the largest deviation before it.')
a['sm_ftle']=('Finite-time Lyapunov exponents were computed from the tangent dynamics with renormalization every unit of time, for 80 initial points on circles of radius 0.02–2.4 around the origin '
 f'(script lyap.py). At $A$ = 0.2 the mean exponent is {a["ftle500"]} at $T$ = 500 and {a["ftle2000"]} at $T$ = 2000 averaged over all points, a decrease close to the $(\\rm{{ln }}T)/T$ decay of regular motion. '
 f'At $A$ = 0.85 the points within radius 0.1 of the origin give {a["ftle85"]} at $T$ = 1000, while points at radius 0.8 and beyond give 0.003–0.006, as for regular motion. '
 f'The break times at $A$ = 0.85, from quantum runs with $L$ = 32 and $M$ = 8192 and the mean of two standardized Monte Carlo samples of $4×10^{{4}}$ trajectories (seeds 11 and 2, script longchaos2.py), are {a.get("tb085","–")} at $ℏ_{{eff}}$ = 0.5, 0.25, 0.125, 0.06 and 0.03.')
a['sm_escape']=('Escape from the cosine well is studied with classical transport of the vacuum Wigner ensemble (polar quadrature, 32 × 96 points), with escape defined as reaching $|x|$ > $π$. '
 'Figure S1(a) shows the escaped fraction by $t$ = 60. For $ℏ_{eff}$ ≤ 0.25 it stays below 6% up to $A$ = 0.55 and rises to about one half at $A$ ≈ 0.65. '
 'The threshold depends on the observation time (Fig. S1(b)). At $ℏ_{eff}$ = 0.125 half of the ensemble has escaped at $A$ ≈ 0.66 by $t$ = 60, at $A$ ≈ 0.57 by $t$ = 200 and at $A$ ≈ 0.53 by $t$ = 400. '
 'Escape in the driven cosine well is the escape of the parametrically excited pendulum, whose global bifurcations and chaotic transients are described in Refs. [29,30] of the main text. '
 'It is a classical process, and the initial width affects it mainly through the spill-over of the initial distribution at large $ℏ_{eff}$.')
a['figS1_aspect']=0.4784
M=a['mcu']; P=a['peak']; H3=('0.125','0.06','0.03'); pc=lambda x: f"{100*x:.2f}%"
a['mcsd']=', '.join(pc(M[h]['rel_std_between_samples_to_peak']) for h in H3[:2])+' and '+pc(M['0.03']['rel_std_between_samples_to_peak'])
a['mcse']=', '.join(pc(M[h]['rel_std_of_mean_to_peak']) for h in H3[:2])+' and '+pc(M['0.03']['rel_std_of_mean_to_peak'])
a['mcse_pk']=f"{100*min(M[h]['rel_std_of_mean_at_peak'] for h in H3):.2f}–{100*max(M[h]['rel_std_of_mean_at_peak'] for h in H3):.2f}%"
a['mcwhole']=f"{100*min(M[h]['rel_std_mean_whole_run'] for h in H3):.1f}–{100*max(M[h]['rel_std_mean_whole_run'] for h in H3):.1f}%"
a['mcutb']=f"{max(max(v['tb_seeds'])-min(v['tb_seeds']) for v in M.values()):.2f}"
a['chtb']=f"{max(max(v)-min(v) for v in a['chaos_tb_seeds'].values()):.2f}" if a.get('chaos_tb_seeds') else '–'
a['ch_tb4']=f"{a['ch_tb4_025']:.1f}" if a.get('ch_tb4_025') else '–'
a['ch_tb025']=f"{[x for x in a['chaos'] if x[0]==0.25][0][1]:.1f}" if a.get('chaos') else '–'
a['devpre']=', '.join(pc(P[h]['max_dev_before']) for h in H3[:2])+' and '+pc(P['0.03']['max_dev_before'])
a['tpre']=', '.join(f"{P[h]['t_max_dev_before']:.0f}" for h in H3[:2])+' and '+f"{P['0.03']['t_max_dev_before']:.0f}"
a['devpk3']=', '.join(pc(P[h]['dev_at_qpk']) for h in H3[:2])+' and '+pc(P['0.03']['dev_at_qpk'])
fac=lambda h,k1,k2: P[h][k1]/M[h][k2]
a['fac_pre']=', '.join(f"{fac(h,'max_dev_before','rel_std_of_mean_to_peak'):.0f}" for h in H3[:2])+' and '+f"{fac('0.03','max_dev_before','rel_std_of_mean_to_peak'):.0f}"
fp=[fac(h,'dev_at_qpk','rel_std_of_mean_at_peak') for h in H3]; a['fac_pk']=f"{min(fp):.0f}–{max(fp):.0f}"
a['devpre_bound']=f"{100*max(P[h]['max_dev_before'] for h in H3)+0.05:.1f}%"
ST=json.load(open('sm_tables.json'))
a['collapse_failed']='; '.join(f'{n} at $ℏ_{{eff}}$ = {h} ($R^{{2}}$ = {r2}, spread {sp})' for n,h,r2,sp in ST['collapse_failed']) or 'none'
import PIL.Image as I; im=I.open('../figs/Fig4.png'); a['fig4_aspect']=im.size[1]/im.size[0]
json.dump(a,open('longtime_vals.json','w'),indent=1,ensure_ascii=False)
print('merged')
