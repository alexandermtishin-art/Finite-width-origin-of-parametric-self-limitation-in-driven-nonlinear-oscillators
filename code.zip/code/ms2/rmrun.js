const D = require('docx');
class StyAttr extends D.XmlAttributeComponent { constructor(o) { super(o); this.xmlKeys = { val: 'm:val' }; } }
class MSty extends D.XmlComponent { constructor() { super('m:sty'); this.root.push(new StyAttr({ val: 'p' })); } }
class MRPr extends D.XmlComponent { constructor() { super('m:rPr'); this.root.push(new MSty()); } }
class MT extends D.XmlComponent { constructor(t) { super('m:t'); this.root.push(t); } }
class RomanMathRun extends D.XmlComponent { constructor(t) { super('m:r'); this.root.push(new MRPr()); this.root.push(new MT(t)); } }
module.exports = { RomanMathRun };

// Generic OMML element builder and accent objects (letter with a hat, tilde or bar placed by the math engine).
class ValAttr extends D.XmlAttributeComponent { constructor(o) { super(o); this.xmlKeys = { val: 'm:val' }; } }
class XE extends D.XmlComponent {
  constructor(tag, kids = [], val) { super(tag); if (val !== undefined) this.root.push(new ValAttr({ val })); for (const k of kids) this.root.push(k); }
}
const ital = (t) => new XE('m:r', [new XE('m:t', [t])]);
const accent = (base, chr) => new XE('m:acc', [new XE('m:accPr', [new XE('m:chr', [], chr)]), new XE('m:e', [ital(base)])]);
const subOf = (b, s) => new XE('m:sSub', [new XE('m:e', [b]), new XE('m:sub', s)]);
module.exports.XE = XE; module.exports.ital = ital; module.exports.accent = accent; module.exports.subOf = subOf;
