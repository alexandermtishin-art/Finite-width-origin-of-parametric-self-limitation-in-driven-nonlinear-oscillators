// Shared helpers: inline-math markup -> TextRuns; OMML display equations; captions; tables.
const D = require('docx');
const { Paragraph, TextRun, AlignmentType, Table, TableRow, TableCell, WidthType, BorderStyle,
        Math: OMath, MathRun, MathFraction, MathSuperScript, MathSubScript, MathFunction,
        MathRoundBrackets, ImageRun, VerticalAlign } = D;
const ACC = require('./rmrun.js'); const { RomanMathRun } = ACC;
const FONT = 'Times New Roman', SZ = 24, SPACING = { line: 360, lineRule: 'auto', after: 120 };

// ---------- inline markup ----------
// Outside $...$: plain text; **bold** allowed.
// Inside $...$: letters italic (Latin, Greek, ℏ), digits/operators roman;
//   \rm{...} roman text; _{...} roman subscript; _(...) italic subscript; ^{...} superscript (math rules).
const LETTER = /[A-Za-zα-ωΑ-Ωℏϕ]/;
function mathRuns(s, base) {
  const out = []; let i = 0; let buf = ''; let bufIt = null;
  const flush = () => { if (buf) { out.push(new TextRun({ text: buf, font: FONT, size: SZ, italics: bufIt, ...base })); buf = ''; } };
  const push = (ch, it) => { if (bufIt !== it) { flush(); bufIt = it; } buf += ch; };
  const grab = (open, close) => { let depth = 1, j = i; while (depth) { j++; if (s[j] === open) depth++; else if (s[j] === close) depth--; } const inner = s.slice(i + 1, j); i = j + 1; return inner; };
  while (i < s.length) {
    const c = s[i];
    // letter + combining accent (U+0300-036F): inline OMML accent object, placed by the math engine;
    // a following subscript or superscript stays a text run, as elsewhere in the document.
    if (/[\u0300-\u036f]/.test(s[i + 1] || '') && !base.subScript && !base.superScript) {
      if (buf && !/\s$/.test(buf)) buf += '\u2060'; flush(); let j = i + 1; let chr = '';
      while (j < s.length && /[\u0300-\u036f]/.test(s[j])) chr += s[j++];
      out.push(new OMath({ children: [ACC.accent(c, chr)] })); i = j;
      if (i < s.length && !/\s/.test(s[i])) push('\u2060', false);
      continue;
    }
    if (s.startsWith('\\rm{', i)) { i += 3; const t = grab('{', '}'); for (const ch of t) push(ch, false); continue; }
    if (c === '_' && s[i + 1] === '{') { flush(); i += 1; const t = grab('{', '}'); out.push(...romanRuns(t, { ...base, subScript: true })); continue; }
    if (c === '_' && s[i + 1] === '(') { flush(); i += 1; const t = grab('(', ')'); out.push(...mathRuns(t, { ...base, subScript: true })); continue; }
    if (c === '^' && s[i + 1] === '{') { flush(); i += 1; const t = grab('{', '}'); out.push(...mathRuns(t, { ...base, superScript: true })); continue; }
    push(c, LETTER.test(c) && !(c === 'π')); i++;
  }
  flush(); return out;
}
function romanRuns(s, base) { return [new TextRun({ text: s, font: FONT, size: SZ, ...base })]; }
function runs(text, extra = {}) {
  const out = []; const parts = text.split(/(\$[^$]*\$|\*\*[^*]+\*\*)/);
  for (const p of parts) {
    if (!p) continue;
    if (p.startsWith('$')) out.push(...mathRuns(p.slice(1, -1), extra));
    else if (p.startsWith('**')) out.push(new TextRun({ text: p.slice(2, -2), font: FONT, size: SZ, bold: true, ...extra }));
    else out.push(new TextRun({ text: p, font: FONT, size: SZ, ...extra }));
  }
  return out;
}
const P = (t, o = {}) => new Paragraph({ spacing: SPACING, alignment: o.align || AlignmentType.JUSTIFIED, keepNext: o.keepNext, children: runs(t, o.run || {}) });
const H = (t) => new Paragraph({ spacing: { line: 360, lineRule: 'auto', before: 240, after: 120 }, keepNext: true, children: runs(t, { bold: true }) });
const H2 = (t) => new Paragraph({ spacing: { line: 360, lineRule: 'auto', before: 180, after: 60 }, keepNext: true, children: runs(t, { bold: true }) });

// ---------- OMML ----------
const m = (t) => new MathRun(t);
const fr = (n, d) => new MathFraction({ numerator: n, denominator: d });
const sup = (b, e) => new MathSuperScript({ children: b, superScript: e });
const sub = (b, s) => new MathSubScript({ children: b, subScript: s });
const fn = (name, arg) => new MathFunction({ name: [m(name)], children: arg });
const br = (c) => new MathRoundBrackets({ children: c });
const noBorder = { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' };
const NB = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder };
function EQ(children, num) {
  return new Table({
    width: { size: 9026, type: WidthType.DXA }, columnWidths: [8126, 900], borders: { ...NB, insideHorizontal: noBorder, insideVertical: noBorder },
    rows: [new TableRow({ cantSplit: true, children: [
      new TableCell({ width: { size: 8126, type: WidthType.DXA }, borders: NB, verticalAlign: VerticalAlign.CENTER,
        children: (Array.isArray(children[0]) ? children : [children]).map(ch => new Paragraph({ alignment: AlignmentType.CENTER, spacing: { line: 360, lineRule: 'auto', before: 60, after: 60 }, children: [new OMath({ children: ch })] })) }),
      new TableCell({ width: { size: 900, type: WidthType.DXA }, borders: NB, verticalAlign: VerticalAlign.CENTER,
        children: [new Paragraph({ alignment: AlignmentType.RIGHT, spacing: { line: 360, lineRule: 'auto', before: 60, after: 60 }, children: [new TextRun({ text: `(${num})`, font: FONT, size: SZ })] })] })] })]
  });
}

// ---------- figures, captions, tables ----------
const fs = require('fs');
function FIG(path, widthIn, aspect) {
  const w = Math.round(widthIn * 96), h = Math.round(w * aspect);
  return new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120, after: 60 },
    children: [new ImageRun({ type: 'png', data: fs.readFileSync(path), transformation: { width: w, height: h } })] });
}
const CAP = (t) => new Paragraph({ spacing: SPACING, alignment: AlignmentType.JUSTIFIED, children: runs(t) });
const TCAP = (t) => new Paragraph({ spacing: SPACING, alignment: AlignmentType.JUSTIFIED, keepNext: true, children: runs(t) });
const thin = { style: BorderStyle.SINGLE, size: 4, color: '000000' };
function TABLE(header, rows, widths) {
  const total = widths.reduce((a, b) => a + b, 0);
  const mk = (cells, last) => new TableRow({ cantSplit: true, tableHeader: false, children: cells.map((c, j) => new TableCell({
    width: { size: widths[j], type: WidthType.DXA }, borders: { top: thin, bottom: thin, left: thin, right: thin },
    margins: { top: 40, bottom: 40, left: 80, right: 80 },
    children: [new Paragraph({ keepNext: !last, spacing: { line: 360, lineRule: 'auto', after: 0 }, children: runs(c) })] })) });
  const hr = mk(header, false); hr.options = hr.options;
  return new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: widths,
    rows: [new TableRow({ cantSplit: true, tableHeader: true, children: header.map((c, j) => new TableCell({
      width: { size: widths[j], type: WidthType.DXA }, borders: { top: thin, bottom: thin, left: thin, right: thin },
      margins: { top: 40, bottom: 40, left: 80, right: 80 },
      children: [new Paragraph({ keepNext: true, spacing: { line: 360, lineRule: 'auto', after: 0 }, children: runs(c) })] })) }),
      ...rows.map((r, i) => mk(r, i === rows.length - 1))] });
}
module.exports = { D, P, H, H2, runs, m, fr, sup, sub, fn, br, EQ, FIG, CAP, TCAP, TABLE, FONT, SZ, SPACING };
