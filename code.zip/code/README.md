# Code and data: Early parametric gain of a driven anharmonic oscillator

Folders
- `resid/`  calculation scripts, shared modules and all result files (JSON, NPZ).
- `figs/`   figure scripts (Fig1-4, FigS1); they read `../resid/`.
- `ms2/`    builders of the manuscript, Supplementary Material and response letter (node + docx); they read `../figs/` and the JSON files written by `resid/longtime_vals.py`, `resid/sm_tables.py` and `ms2/merge_vals.py`.

Two ways to reproduce
1. Figures and tables from the shipped results (minutes): run the last block of `resid/run_all.sh`
   (`python3 ms_numbers2.py; python3 sm_tables.py`, then the figure scripts in `figs/`, then `ms2/merge_vals.py` and the node builders).
2. Everything from an empty results folder (about 6 h on one core): `cd resid; ./run_all.sh`.
   The early-time part (hier_cos, p01-p03, collapse) was re-run from an empty folder before release and reproduced
   early.json, conv.json, states.json, collapse.json and hierarchy_cos.json to machine precision.

Modules
- `resid.py`  grid split-operator propagator (potential at the step midpoint), Gauss-Hermite Liouville transport, smoothing and fit (W1, W2).
- `gen.py`    Fock and squeezed initial states, polar quadratures, signed Wigner function of |1>.
- `cosq.py`   cosine well, quantum and classical.
- `hierarchy.py`, `hier_cos.py`  closed moment hierarchy; kappa1 and kappa2 for Kerr, cosine and squeezed initial moments.
- `SM_grid_engine.py`  grid, potentials and window average (shared helpers).

Outputs (main ones)
| file | content | used in |
|---|---|---|
| early.json | lambda_qm/lambda_harm, lambda_cl/lambda_harm, Delta, R^2, W2 spread, accepted flag; Kerr A = 0.1, 0.2, 0.4 and cosine | Fig. 2, Tables II, S2-S4 |
| conv.json | grid, time-step and quadrature changes of Delta | Table I, S1, error bars |
| states.json | vacuum, |1>, thermal (n <= 8 and n <= 20), squeezed | Fig. 2b, Tables S6, S7 |
| collapse.json | ten classical distributions at five widths, with fit statistics | Fig. 3, Table S5 |
| hierarchy_cos.json | kappa1, kappa2 | Table II, Figs. 2, 3 |
| long_q_*.npz, longmc2_*.npz, chaos_q_*.npz, chaos_c2_*.npz | long-time covariance; classical = mean of standardized MC samples | Fig. 4, Table S8 |
| fig4data.json, ../ms2/longtime_vals_auto.json | long-time numbers | Sec. V, Fig. 4 |

Acceptance criteria: a rate is used quantitatively only if R^2 >= 0.98 (W1) and the half-window slopes differ by at most 10% (W2). Every result file stores both statistics and an `ok` flag; figures plot only accepted rates.

Notes
- Time labels: every recorded state is labelled with the time at the end of its step, and recording happens every `rec` steps counted from the end of the first step, so halving the step with `rec` doubled reproduces the same recording times. Long-time files written before this convention carry no `tlabel` entry; `tio.load` corrects them by one step.
- Numerical uncertainty of each quantum-classical difference: 4/3 of its change when the step is halved (conv.json for the early-time series, `ddt` in states.json).
- Monte Carlo sampling uncertainty: spread of independent standardized samples (mc_uncertainty.json, written by longtime_vals.py).

Notes on the procedure
- The moment hierarchy (hierarchy.py, hier_cos.py, rcollapse.py) is evaluated at the recording times of resid.py,
  t = 0.012, 0.024, ... (function hierarchy.rec_times), and passed through the same trailing average and fit.
  The first smoothed point is t = 3.132 in both.
- Long-time classical references are means of Monte Carlo samples standardized to the exact initial covariance
  (longmc2.py, seeds 11, 2, 3 at A = 0.2; longchaos2.py, seeds 11, 2 at A = 0.85). Standardizing the full covariance
  is required: rescaling a sample by one factor to the exact initial sigma_max leaves an offset of about 0.5%.
- longtime_vals.py reports, for each width, the deviation at the first quantum maximum and the largest deviation
  before it (Table S8), and the standard error of the classical mean from the spread of the samples.
- tio.load returns every series labelled with the time at the end of the step that produced each recorded state.
