import json, numpy as np, sys
sys.path.insert(0,'.'); from style import *
from common import load
E,S,K,ERR=load()
fig,(a,b)=plt.subplots(1,2,figsize=(9.2,5.1))
k02=E['kerr']['0.2']; h=np.array(sorted(map(float,k02))); q=np.array([k02[str(x) if str(x) in k02 else repr(x)]['q'] for x in h]); c=np.array([k02[str(x)]['c'] for x in h])
hh=np.geomspace(0.025,0.6,200); chi=hh/24; k1=K['kerr_0.2']['k1']; k2=K['kerr_0.2']['k2']
a.axhline(1,ls='--',color=GREY,lw=1.5); a.text(0.028,1.002,'harmonic, same window',fontsize=12.5,color=GREY,va='bottom')
m=hh<=0.2; a.plot(hh[m],1-2*k1*chi[m],'-',color=C2,lw=1.6,alpha=0.85); a.plot(hh[m],1-2*k1*chi[m]+k2*chi[m]**2,'-',color=C1,lw=1.6,alpha=0.85)
a.plot(h,q,'s',color=C1,ms=9,mec='white',mew=1.3,label='quantum'); a.plot(h,c,'o',color=C2,ms=9,mec='white',mew=1.3,label='classical (Wigner)')
a.plot([],[],'-',color=GREY,lw=1.6,label='hierarchy (leading order)')
a.set_xscale('log'); a.set_xticks([0.03,0.06,0.125,0.25,0.5]); a.set_xticklabels(['0.03','0.06','0.125','0.25','0.5'])
a.set_xlabel(r'$\hbar_{\rm eff}$'); a.set_ylabel(r'$\lambda/\lambda_{\rm harm}$'); a.set_ylim(0.855,1.012)
a.legend(frameon=False,loc='center left',bbox_to_anchor=(0.0,0.32)); clean(a); panel(a,'(a)')
for A,col,mk in ((0.1,C2,'^'),(0.2,C1,'o'),(0.4,C3,'D')):
    d=E['kerr'][str(A)]; pts=sorted((float(x),v['d'],ERR[f'kerr_{A}'][x]) for x,v in d.items() if v['ok'])
    hx=np.array([p[0] for p in pts]); dy=np.array([p[1] for p in pts]); ey=np.array([p[2] for p in pts])
    b.plot(hh,K[f'kerr_{A}']['k2']*(hh/24)**2,'-',color=col,lw=1.5,alpha=0.8)
    b.errorbar(hx,dy,yerr=ey,fmt=mk,color=col,ms=8,mec='white',mew=1.0,ecolor=col,elinewidth=1.4,capsize=3,label=rf'$A={A}$',zorder=4)
cw=[(float(x),v['d']) for x,v in E['cos'].items() if v['ok']]
b.plot([p[0] for p in cw],[p[1] for p in cw],'o',mfc='none',mec=INK,mew=1.4,ms=15,zorder=3,label=r'cosine well, $A=0.2$')
for st,mk,lab,sh in (('fock1','P',r'$|1\rangle$, $A=0.2$',0.83),('thermal_N20','X',r'thermal, $A=0.2$',1.20)):
    xs=[float(x)*sh for x in ('0.25','0.125')]; ys=[S[x][st]['d'] for x in ('0.25','0.125')]   # shifted horizontally for visibility (stated in the caption)
    b.plot(xs,ys,mk,color='white',mec=INK,mew=1.6,ms=11,label=lab)
b.set_xscale('log'); b.set_yscale('log'); b.set_xticks([0.03,0.06,0.125,0.25,0.5]); b.set_xticklabels(['0.03','0.06','0.125','0.25','0.5'])
b.set_xlabel(r'$\hbar_{\rm eff}$'); b.set_ylabel(r'$(\lambda_{\rm qm}-\lambda_{\rm cl})/\lambda_{\rm harm}$')
b.legend(frameon=False,loc='upper center',bbox_to_anchor=(0.45,-0.2),ncol=2,fontsize=11.5,handlelength=1.2,columnspacing=0.9); clean(b); panel(b,'(b)')
fig.tight_layout(w_pad=2.5,rect=(0,0.02,1,1)); fig.savefig('Fig2.png'); fig.savefig('Fig2.pdf')
