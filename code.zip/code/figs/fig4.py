import json, numpy as np, sys
sys.path.insert(0, '.'); from style import *
import matplotlib.gridspec as gs
R = '../resid/'
rc = json.load(open(R + 'rcollapse.json')); F4 = json.load(open(R + 'fig4data.json'))
HB = ['0.5', '0.25', '0.125', '0.06', '0.03']
fig = plt.figure(figsize=(9.2, 8.6)); g = gs.GridSpec(2, 2, height_ratios=[1, 1.05], hspace=0.42, wspace=0.34)
a = fig.add_subplot(g[0, 0]); b = fig.add_subplot(g[0, 1]); c = fig.add_subplot(g[1, :])
# (a) r(t)
for k, col in zip(HB[:4], RAMP[:4]):
    d = rc['num'][k]; t = np.array(d['t']); r = np.array(d['r']); m = t <= 26
    a.plot(t[m], r[m], '-', color=col, lw=2.0, label=rf'$\hbar_{{\rm eff}}={k}$')
t = np.array(rc['t']); m = t <= 26
a.plot(t[m], np.array(rc['r_th'])[m], '--', color=INK, lw=2.0, label='hierarchy')
a.set_yscale('log'); a.set_ylim(3, 4e4); a.set_xlim(3, 26)
a.set_xlabel(r'$\Omega_0 t$'); a.set_ylabel(r'$r(t)=(\sigma_{\rm qm}/\sigma_{\rm cl}-1)/\chi^2$')
a.legend(frameon=False, fontsize=10.5, loc='upper left', handlelength=1.3, labelspacing=0.25, borderaxespad=0.2, ncol=2, columnspacing=0.8); clean(a); panel(a, '(a)')
# (b) break time in units of 1/mu
MU = {'A02': 0.049942, 'A085': 0.208216}
hh = np.geomspace(0.025, 0.6, 50)
for key, col, mk, lab in (('A02', C1, 'o', r'$A=0.2$'), ('A085', C2, 'D', r'$A=0.85$')):
    ks = sorted(F4[key], key=float, reverse=True); h = np.array([float(k) for k in ks])
    tb = MU[key]*np.array([F4[key][k]['tb'] for k in ks]); tp = MU[key]*np.array([F4[key][k]['tpk'] for k in ks])
    b.plot(h, tb, mk, color=col, ms=10 if mk == 'o' else 9, mec='white', mew=1.3, label=r'$t_b$, ' + lab, zorder=3)
    b.plot(h, tp, 's' if mk == 'o' else 'd', color=col, mfc='white', mec=col, mew=1.6, ms=8, label='first max., ' + lab, zorder=3)
    p = np.polyfit(np.log(1/h), tb, 1); b.plot(hh, np.polyval(p, np.log(1/hh)), '-', color=col, lw=1.3, alpha=0.7)
b.set_xscale('log'); b.set_xticks([0.03, 0.06, 0.125, 0.25, 0.5]); b.set_xticklabels(['0.03', '0.06', '0.125', '0.25', '0.5'])
b.set_xlabel(r'$\hbar_{\rm eff}$'); b.set_ylabel(r'$\mu t$'); b.set_ylim(0, 9.5)
b.legend(frameon=False, fontsize=10.5, loc='upper right', handlelength=1.0, labelspacing=0.3); clean(b); panel(b, '(b)')
# (c) long-time covariance
for k, col in (('0.5', RAMP[0]), ('0.125', RAMP[2]), ('0.03', RAMP[4])):
    d = F4['A02'][k]; t = np.array(d['t'])
    c.plot(t, d['q'], '-', color=col, lw=2.2, label=rf'quantum, $\hbar_{{\rm eff}}={k}$')
    c.plot(t, d['c'], '--', color=col, lw=2.0, label=rf'classical, $\hbar_{{\rm eff}}={k}$')
    if d['tb']: c.axvline(d['tb'], ymin=0, ymax=0.06, color=col, lw=3)
c.set_yscale('log'); c.set_xlim(0, 250); c.set_xlabel(r'$\Omega_0 t$'); c.set_ylabel(r'$\sigma_{\rm max}/\hbar_{\rm eff}$')
c.legend(frameon=False, fontsize=11, ncol=3, loc='upper center', bbox_to_anchor=(0.5, 1.22), handlelength=1.6, columnspacing=1.0)
clean(c); panel(c, '(c)')
fig.savefig('Fig4.png', bbox_inches='tight'); fig.savefig('Fig4.pdf', bbox_inches='tight')
import PIL.Image as I; im = I.open('Fig4.png'); print('aspect', im.size[1]/im.size[0])
