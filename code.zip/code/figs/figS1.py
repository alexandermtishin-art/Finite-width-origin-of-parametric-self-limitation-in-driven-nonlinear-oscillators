import json, numpy as np, sys
sys.path.insert(0,'.'); from style import *
R='../resid/'
em=json.load(open(R+'escape_map.json')); et=json.load(open(R+'escape_time_0.125.json'))
fig,(a,b)=plt.subplots(1,2,figsize=(9.2,4.4))
for r,col in zip(em,RAMP):
    a.plot(r['As'],r['P'],'o-',color=col,ms=6,lw=1.8,label=rf"$\hbar_{{\rm eff}}={r['hb']:g}$")
a.set_xlabel('drive amplitude $A$'); a.set_ylabel('escaped fraction'); a.text(0.97,0.05,r'$\Omega_0t=60$',transform=a.transAxes,ha='right',fontsize=12); a.legend(frameon=False,fontsize=11,loc='upper left'); clean(a); panel(a,'(a)')
for (T,v),col,mk in zip(et['P'].items(),(C1,C2,C3),('o','s','D')):
    b.plot(et['As'],v,mk+'-',color=col,ms=7,lw=1.8,mec='white',label=rf'$\Omega_0t={float(T):.0f}$')
b.set_xlabel('drive amplitude $A$'); b.set_ylabel('escaped fraction'); b.legend(frameon=False,fontsize=11.5,loc='upper left'); clean(b); panel(b,'(b)')
b.text(0.97,0.05,r'$\hbar_{\rm eff}=0.125$',transform=b.transAxes,ha='right',fontsize=12)
fig.tight_layout(w_pad=2.5); fig.savefig('FigS1.png'); fig.savefig('FigS1.pdf')
import PIL.Image as I; im=I.open('FigS1.png'); print(im.size[1]/im.size[0])
