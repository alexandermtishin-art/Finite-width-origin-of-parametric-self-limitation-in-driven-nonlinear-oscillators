import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
C1,C2,C3='#2a78d6','#eb6834','#1baf7a'; GREY='#7a7a7a'; INK='#1a1a1a'
RAMP=['#86b6ef','#5598e7','#2a78d6','#1c5cab','#0d366b']
plt.rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],'mathtext.fontset':'dejavuserif',
 'font.size':15,'axes.labelsize':16,'axes.titlesize':15,'xtick.labelsize':14,'ytick.labelsize':14,'legend.fontsize':12.5,
 'axes.linewidth':1.2,'xtick.major.width':1.2,'ytick.major.width':1.2,'xtick.major.size':6,'ytick.major.size':6,
 'xtick.minor.size':3.5,'ytick.minor.size':3.5,'lines.linewidth':2.4,'lines.markersize':8,'savefig.dpi':400,
 'axes.edgecolor':INK,'text.color':INK,'axes.labelcolor':INK,'xtick.color':INK,'ytick.color':INK})
def clean(ax):
    for s in ['top','right']: ax.spines[s].set_visible(False)
    ax.grid(alpha=0.3,color='#cccccc',which='major',lw=0.8)
def panel(ax,lab): ax.text(-0.2,1.03,lab,transform=ax.transAxes,fontsize=17,fontweight='bold',va='bottom')
