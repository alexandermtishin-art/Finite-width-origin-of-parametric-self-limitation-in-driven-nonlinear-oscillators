import json
R = '../resid/'
RICH = 4.0/3.0   # Richardson factor for a second-order scheme: error(dt) ~ (4/3) |Delta(dt/2) - Delta(dt)|
def load():
    E = json.load(open(R + 'early.json')); H = json.load(open(R + 'hierarchy_cos.json'))
    S = json.load(open(R + 'states.json')); C = json.load(open(R + 'conv.json'))
    k = {key: dict(k1=-v['g1']/(2*v['F0']), k2=v['c2']/v['F0']) for key, v in H.items()}
    err = {ser: {hb: RICH*abs(v) for hb, v in d.items()} for ser, d in C['dt'].items()}
    return E, S, k, err
