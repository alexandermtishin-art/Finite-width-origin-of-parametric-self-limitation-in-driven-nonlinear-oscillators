import json, numpy as np, sys
sys.path.insert(0,'.'); from style import *
from common import load
E,S,K,ERR=load(); kap=K['kerr_0.2']['k1']
D=json.load(open('../resid/collapse.json'))
sty={'vac_wigner':(C1,'o',True,r'Wigner, $|0\rangle$'),'vac_husimi':(C1,'s',True,r'Husimi, $|0\rangle$'),'vac_disk':(C1,'^',False,r'disk, $\langle u\rangle=1$'),
 'vac_ring':(C1,'D',False,r'ring, $u=1$'),'vac_originring':(C1,'*',False,r'point + ring, matched to $|0\rangle$'),
 'f1_wigner':(C2,'o',True,r'signed Wigner, $|1\rangle$'),'f1_gauss':(C2,'s',True,r'Gaussian, $\langle u\rangle=3$'),'f1_disk':(C2,'^',False,r'disk, $\langle u\rangle=3$'),
 'f1_ring':(C2,'D',False,r'ring, $u=3$'),'f1_tworing':(C2,'*',False,r'two rings, matched to $|1\rangle$')}
fig,(a,b)=plt.subplots(1,2,figsize=(9.2,5.6))
xx=np.geomspace(1e-3,0.2,100); a.plot(xx,kap*xx,'-',color=INK,lw=1.6,label='hierarchy, leading order'); b.axhline(1,color=INK,lw=1.6)
for name,(c,mk,fill,lab) in sty.items():
    e=D[name]; ks=[k for k in e['rel'] if e['ok'][k]]; hb=np.array([float(k) for k in ks]); rel=np.array([e['rel'][k] for k in ks])
    o=np.argsort(hb); hb,rel=hb[o],rel[o]; x=hb/24*e['m2']/e['m1']; y=1-rel
    kw=dict(color=c,mec=c,mfc=c if fill else 'white',mew=1.6,ms=13 if mk=='*' else 9,ls='none')
    a.plot(x,y,mk,label=lab,**kw); b.plot(x,y/(kap*x),mk,**kw); b.plot(x,y/(kap*x),'-',color=c,lw=0.8,alpha=0.5)
for ax in (a,b): ax.set_xscale('log'); ax.set_xlabel(r'$\chi\,\langle u^2\rangle/\langle u\rangle$'); clean(ax); ax.set_xlim(1.0e-3,0.15)
a.set_yscale('log'); a.set_ylabel(r'$1-\lambda_{\rm cl}/\lambda_{\rm harm}$'); b.set_ylabel('ratio to first order')
panel(a,'(a)'); panel(b,'(b)')
h,l=a.get_legend_handles_labels()
fig.legend(h,l,loc='lower center',ncol=2,frameon=False,fontsize=12,bbox_to_anchor=(0.5,-0.01),handlelength=1.4,columnspacing=1.2)
fig.tight_layout(rect=(0,0.27,1,1),w_pad=2.5); fig.savefig('Fig3.png'); fig.savefig('Fig3.pdf'); print('kappa',kap)
