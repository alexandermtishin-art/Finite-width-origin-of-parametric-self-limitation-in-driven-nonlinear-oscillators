"""Finite-time Lyapunov exponents of the driven Kerr oscillator (A=0.2, beta=1/6), vectorised over initial points.
Points: near the origin (hyperbolic fixed point occupied by the vacuum ensemble) and on a grid of initial amplitudes."""
import numpy as np, json, sys
A = float(sys.argv[2]); beta = 1/6; dt = 4e-3; T = float(sys.argv[1])
r0 = np.array([0.02, 0.05, 0.1, 0.2, 0.4, 0.8, 1.2, 1.6, 2.0, 2.4]); th = np.linspace(0, 2*np.pi, 9)[:-1]
R0, TH = np.meshgrid(r0, th, indexing='ij'); x = (R0*np.cos(TH)).ravel(); p = (R0*np.sin(TH)).ravel()
dx = np.ones_like(x); dp = np.zeros_like(x); s = np.zeros_like(x)
def f(x, p, dx, dp, t):
    O2 = 1 + A*np.cos(2*t); return p, -O2*x - beta*x**3, dp, -(O2 + 3*beta*x**2)*dx
t = 0.0
for i in range(int(T/dt)):
    a = f(x, p, dx, dp, t); b = f(x+dt/2*a[0], p+dt/2*a[1], dx+dt/2*a[2], dp+dt/2*a[3], t+dt/2)
    c = f(x+dt/2*b[0], p+dt/2*b[1], dx+dt/2*b[2], dp+dt/2*b[3], t+dt/2); d = f(x+dt*c[0], p+dt*c[1], dx+dt*c[2], dp+dt*c[3], t+dt)
    x = x+dt/6*(a[0]+2*b[0]+2*c[0]+d[0]); p = p+dt/6*(a[1]+2*b[1]+2*c[1]+d[1])
    dx = dx+dt/6*(a[2]+2*b[2]+2*c[2]+d[2]); dp = dp+dt/6*(a[3]+2*b[3]+2*c[3]+d[3]); t += dt
    if i % 250 == 0:
        n = np.hypot(dx, dp); s += np.log(n); dx /= n; dp /= n
s += np.log(np.hypot(dx, dp)); L = (s/T).reshape(R0.shape)
out = {'T': T, 'r0': r0.tolist(), 'lyap_mean': L.mean(1).tolist(), 'lyap_max': L.max(1).tolist(), 'lyap_min': L.min(1).tolist()}
print(json.dumps(out)); json.dump(out, open(f'lyap_A{A}_{int(T)}.json', 'w'))
