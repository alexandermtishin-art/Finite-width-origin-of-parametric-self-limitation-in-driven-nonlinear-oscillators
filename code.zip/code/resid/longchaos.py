"""Long-time quantum dynamics at drive amplitude A (default use 0.85, chaotic layer around the origin), Kerr well.
Usage: python3 longchaos.py A q hbar1 hbar2 ...  -> chaos_q_{A}_{hb}.npz.  The classical branch is longchaos2.py."""
import numpy as np, sys, resid as R
A = float(sys.argv[1]); mode = sys.argv[2]; hbs = [float(h) for h in sys.argv[3:]]; T = 120.0
R.A = A; R.Twin = T
assert mode == 'q', 'classical runs: longchaos2.py'
for hb in hbs:
    t, s = R.quantum(hb, 'vac', L=32.0, M=8192); np.savez(f'chaos_q_{A}_{hb}.npz', t=t, s=s, tlabel='end')
    print(mode, hb, 'done', flush=True)
