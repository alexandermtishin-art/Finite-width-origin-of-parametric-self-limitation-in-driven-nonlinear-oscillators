"""Classical rate relative to lambda_harm, with fit statistics (W1, W2), on the fixed window [3.12, 7.69] (A = 0.2) for isotropic distributions with known (m1, m2) of u.
Tests the hierarchy statement dF_cl/F_h = -kappa * chi * m2/m1 + O(chi^2), kappa = 0.7173/F_h."""
import numpy as np, json, gen as G
import mmatch_lib as MM, resid as R, json as _j
LH = _j.load(open('early.json'))['lharm']['0.2']
G.Twin = 9.0
fam = {  # name: (generator, m1, m2)
 'vac_wigner': (lambda hb: G.polar(hb, 'exp', 1.0), 1, 2),
 'vac_husimi': (lambda hb: G.polar(hb, 'exp', 2.0), 2, 8),
 'vac_disk':   (lambda hb: G.polar(hb, 'disk', 1.0), 1, 4/3),
 'vac_ring':   (lambda hb: G.polar(hb, 'ring', 1.0), 1, 1),
 'vac_originring': (lambda hb: MM.originring(hb), 1, 2),
 'f1_wigner':  (lambda hb: G.polar(hb, 'fock1'), 3, 10),
 'f1_gauss':   (lambda hb: G.polar(hb, 'exp', 3.0), 3, 18),
 'f1_disk':    (lambda hb: G.polar(hb, 'disk', 3.0), 3, 12),
 'f1_ring':    (lambda hb: G.polar(hb, 'ring', 3.0), 3, 9),
 'f1_tworing': (lambda hb: MM.rings(hb, [2, 4], [0.5, 0.5]), 3, 10),
}
out = {}
for hb in (0.5, 0.25, 0.125, 0.0625, 0.03125):
    for name, (gen, m1, m2) in fam.items():
        ts, s = G.c_sigma(*gen(hb)); lam, r2, sp = R.fit(ts, s, 3.12, 7.69)
        e = out.setdefault(name, {'m1': m1, 'm2': m2, 'rel': {}, 'r2': {}, 'sp': {}, 'ok': {}})
        e['rel'][hb] = lam/LH; e['r2'][hb] = r2; e['sp'][hb] = sp; e['ok'][hb] = bool(r2 >= 0.98 and sp <= 0.10)
        print(hb, name, lam/LH, r2, sp, flush=True)
    json.dump(out, open('collapse.json', 'w'), indent=1)
