"""MC Wigner transport to T=250 with the sample standardised to the exact vacuum covariance (removes the O(N^-1/2) initial offset)."""
import numpy as np, sys
A=0.2; beta=1/6; dt=6e-3; rec=2; T=250.0; N=int(sys.argv[1]); args=sys.argv[2:]
SEED=int(args[0][5:]) if args and args[0].startswith('seed=') else 11
if args and args[0].startswith('seed='): args=args[1:]
hbs=[float(h) for h in args]
for hb in hbs:
    rng=np.random.default_rng(SEED); z=rng.normal(size=(2,N)); z-=z.mean(1,keepdims=True)
    L=np.linalg.cholesky(np.cov(z)); z=np.linalg.solve(L,z)          # exact zero mean, unit covariance
    s=np.sqrt(hb/2); x=s*z[0]; p=s*z[1]
    f=lambda x,t: -(1+A*np.cos(2*t))*x-beta*x**3; ts=[]; sig=[]
    for i in range(int(T/dt)):
        t=i*dt
        k1x,k1p=p,f(x,t); k2x,k2p=p+dt/2*k1p,f(x+dt/2*k1x,t+dt/2); k3x,k3p=p+dt/2*k2p,f(x+dt/2*k2x,t+dt/2); k4x,k4p=p+dt*k3p,f(x+dt*k3x,t+dt)
        x=x+dt/6*(k1x+2*k2x+2*k3x+k4x); p=p+dt/6*(k1p+2*k2p+2*k3p+k4p)
        if (i+1)%rec==0:
            Vx=x.var();Vp=p.var();C=np.mean(x*p)-x.mean()*p.mean(); ts.append(t+dt); sig.append(0.5*(Vx+Vp)+np.sqrt(0.25*(Vx-Vp)**2+C**2))
    np.savez(f'longmc2_{hb}.npz' if SEED==11 else f'longmc2_{hb}_seed{SEED}.npz',t=np.array(ts),s=np.array(sig),tlabel='end',N=N); print('done',hb,flush=True)
