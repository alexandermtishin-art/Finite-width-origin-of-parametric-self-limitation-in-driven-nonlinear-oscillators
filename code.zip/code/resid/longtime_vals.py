"""Long-time numbers for the manuscript and Supplement -> ../ms2/longtime_vals.json, and data for Fig. 4 -> fig4data.json."""
import numpy as np, json, os, resid as R, tio
from scipy.signal import argrelextrema
HBS = (0.5, 0.25, 0.125, 0.06, 0.03)

def std_samples(hb):
    """Independent Monte Carlo samples standardized to the exact initial covariance (longmc2.py; seeds 11, 2, 3)."""
    return [f for f in (f'longmc2_{hb}.npz', f'longmc2_{hb}_seed2.npz', f'longmc2_{hb}_seed3.npz') if os.path.exists(f)]

def classical_long(hb):
    """Classical long-time series at A = 0.2: mean of sigma_max over the available standardized samples of 4e4 trajectories each.
    Standardizing the full initial covariance is required: a sample rescaled by one factor to the exact initial sigma_max
    keeps the sampling error of the other second moments and is offset by about 0.5% at t ~ 10-30."""
    files = std_samples(hb); runs = [tio.load(f) for f in files]
    t = runs[0][0]; S = np.array([np.interp(t, *r) for r in runs])
    return t, S.mean(0), f'mc2 x{len(files)}'

def compare(tq, sq, tc, sc, thr=0.05, tmax=None):
    a = R.smooth(tq, sq); b = R.smooth(tc, sc)
    T = min(a[0][-1], b[0][-1]) - 1 if tmax is None else tmax
    tg = np.arange(1.0, T, 0.05); q = np.interp(tg, *a); c = np.interp(tg, *b); dev = np.abs(q/c - 1)
    tb = float(tg[np.argmax(dev > thr)]) if dev.max() > thr else None
    return tg, q, c, dev, tb

V = {}; F4 = {'A02': {}, 'A085': {}}
rows = []; tbs = []; tpks = []; PEAK = {}
for hb in HBS:
    tq_, sq_ = tio.load(f'long_q_{hb}.npz'); tc, sc, src = classical_long(hb)
    tg, q, c, dev, tb = compare(tq_, sq_, tc, sc)
    ipc = np.argmax(c[tg < 100]); tpk = float(tg[ipc])
    ts_, ss_ = R.smooth(tq_, sq_)
    t1 = [ts_[i] for i in argrelextrema(ss_, np.greater, order=300)[0] if 5 < ts_[i] < 245][0]   # first quantum maximum
    ipq = int(np.argmin(abs(tg - t1))); devpk = float(dev[ipq])
    jpre = int(np.argmax(dev[:ipq+1])); devpre = float(dev[jpre]); tpre = float(tg[jpre])   # largest deviation up to the first quantum maximum
    PEAK[str(hb)] = dict(t_qpk=float(tg[ipq]), dev_at_qpk=devpk, max_dev_before=devpre, t_max_dev_before=tpre)
    tbs.append(tb); tpks.append(tpk)
    F4['A02'][str(hb)] = dict(t=tg[::10].tolist(), q=(q[::10]/hb).tolist(), c=(c[::10]/hb).tolist(), tb=tb, tpk=tpk, src=src)
    # quantum extrema (5-period smoothing)
    t, s = R.smooth(tq_, sq_); s = s/hb; ss = s
    mx = [i for i in argrelextrema(ss, np.greater, order=300)[0] if 5 < t[i] < 245]
    mn = [i for i in argrelextrema(ss, np.less, order=300)[0] if 5 < t[i] < 245]
    V[f'q_{hb}'] = dict(max=[(float(t[i]), float(ss[i])) for i in mx], min=[(float(t[i]), float(ss[i])) for i in mn])
    rows.append([f'{hb:g}', f'{tb:.1f}' if tb else '>250', f'{tpk:.1f}', f'{100*devpk:#.2g}%', f'{100*devpre:.2f}% ({tpre:.0f})',
                 f'{V[f"q_{hb}"]["min"][0][0]:.1f}' if V[f'q_{hb}']['min'] else '–',
                 f'{V[f"q_{hb}"]["min"][0][1]:.2f}' if V[f'q_{hb}']['min'] else '–'])
    print(hb, src, 'tb', tb, 'tpk', tpk, 'dev@qpeak', devpk, V[f'q_{hb}'], flush=True)

h = np.array(HBS); tb = np.array(tbs, float)
p = np.polyfit(np.log(1/h), np.log(tb), 1); lg = np.polyfit(np.log(1/h), tb, 1)
# bootstrap-free uncertainty: regression standard error of the power-law slope
X = np.log(1/h); Y = np.log(tb); res = Y - np.polyval(p, X); se = np.sqrt(res@res/(len(X)-2)/np.sum((X-X.mean())**2))
print('power', p[0], '+-', se, 'log slope', lg[0])
rms_pow = float(np.sqrt(np.mean((tb - np.exp(np.polyval(p, X)))**2))); rms_log = float(np.sqrt(np.mean((tb - np.polyval(lg, X))**2)))

# chaotic regime, A = 0.85
ch = []; CH_TB = {}
for hb in HBS:
    fq = f'chaos_q_0.85_{hb}.npz'; fcs = [f for f in (f'chaos_c2_0.85_{hb}_seed11.npz', f'chaos_c2_0.85_{hb}_seed2.npz') if os.path.exists(f)]
    if not (os.path.exists(fq) and fcs): continue
    tq8, sq8 = tio.load(fq); runs = [tio.load(f) for f in fcs]; tc8 = runs[0][0]; sc8 = np.mean([np.interp(tc8, *r) for r in runs], 0)
    tg, q, c, dev, tbc = compare(tq8, sq8, tc8, sc8)
    if hb == 0.25: CH4 = compare(tq8, sq8, tc8, sc8, thr=0.04)[4]   # threshold sensitivity
    if len(fcs) > 1:   # break time from each sample separately
        CH_TB[str(hb)] = [compare(tq8, sq8, *r)[4] for r in runs]
    ipc = np.argmax(c[tg < 40]); ch.append((hb, tbc, float(tg[ipc])))
    F4['A085'][str(hb)] = dict(t=tg[::10].tolist(), q=(q[::10]/hb).tolist(), c=(c[::10]/hb).tolist(), tb=tbc, tpk=float(tg[ipc]))
    print('A=0.85', hb, 'tb', tbc, 'tpk', tg[ipc], flush=True)

# Monte Carlo sampling uncertainty from independent standardized samples (N = 4e4, seeds 2, 3 and, for hbar = 0.125, 11)
MCU = {}
for hb in (0.125, 0.06, 0.03):
    files = std_samples(hb)
    if len(files) < 2: continue
    tq_, sq_ = tio.load(f'long_q_{hb}.npz'); sm = []; tbs_seed = []; tg = None
    for f in files:
        t_, s_ = tio.load(f); tg, q, c, dev, tbk = compare(tq_, sq_, t_, s_); sm.append(c); tbs_seed.append(tbk)
    sm = np.array(sm); rel = sm.std(0, ddof=1)/sm.mean(0); n = len(files)
    t1 = PEAK[str(hb)]['t_qpk']; pre = tg <= t1
    MCU[str(hb)] = dict(n_samples=n, N_each=40000, rel_std_between_samples_to_peak=float(rel[pre].max()),
                        rel_std_of_mean_to_peak=float(rel[pre].max()/np.sqrt(n)), rel_std_of_mean_at_peak=float(rel[np.argmin(abs(tg - t1))]/np.sqrt(n)),
                        rel_std_mean_whole_run=float(rel.mean()), tb_seeds=tbs_seed)
    print('MC uncertainty', hb, MCU[str(hb)], flush=True)
json.dump(MCU, open('mc_uncertainty.json', 'w'), indent=1)
ly5 = json.load(open('lyap_500.json')); ly20 = json.load(open('lyap_2000.json'))
ly85 = json.load(open('lyap_A0.85_1000.json')); ly4 = json.load(open('lyap_A0.4_1000.json'))
rc = json.load(open('rcollapse.json')); tt = np.array(rc['t']); rth = np.array(rc['r_th'])
r10 = float(np.interp(10.0, tt, rth)); r20 = float(np.interp(20.0, tt, rth))

def fmt_list(v): return ', '.join(f'{x:.0f}' for x in v[:-1]) + f' and {v[-1]:.0f}'
q05, q025, q003 = V['q_0.5'], V['q_0.25'], V['q_0.03']
per = lambda d: np.mean(np.diff([x[0] for x in d['max'] if x[1] > 0.8*d['max'][0][1]]))
out = dict(
    tb_lo=f'{tb[0]:.0f}', tb_hi=f'{tb[-1]:.0f}', tb_list=fmt_list(tb), p=f'{p[0]:.2f} ± {se:.2f}', logslope=f'{lg[0]:.0f}',
    gap_lo=f'{tb[2]-tpks[2]:.0f}', gap_hi=f'{tb[4]-tpks[4]:.0f}', nmc='4×10$^{4}$ (one sample, $ℏ_{eff}$ ≥ 0.25) to 1.2×10$^{5}$ (three samples, $ℏ_{eff}$ ≤ 0.125)', mcerr='0.4–0.7%',
    dev_peak=f'{100*max(F4["A02"][str(x)]["q"][0]*0 + 0 for x in (0.125,))}', r10=f'{r10:.0f}', r20=f'{r20:.0f}',
    per05=f'{per(q05):.1f}', per025=f'{per(q025):.1f}', min05=f'{q05["min"][0][1]:.2f}',
    min003=f'{q003["min"][0][1]:.1f}', tmin003=f'{q003["min"][0][0]:.0f}', rev003=f'{100*q003["max"][1][1]/q003["max"][0][1]:.0f}%', t2nd003=f'{q003["max"][1][0]:.0f}',
    ftle500=f'{np.mean(ly5["lyap_mean"]):.4f}', ftle2000=f'{np.mean(ly20["lyap_mean"]):.4f}',
    ftle85=f'{np.mean(ly85["lyap_mean"][:3]):.3f}', ftle4=f'{np.mean(ly4["lyap_mean"]):.4f}',
    fig4b_hb='0.5, 0.125 and 0.03', ftle85v=0, sm_table=rows, sm_table_head=['$ℏ_{eff}$', '$t_{b}$', '$t_{pk}$', 'dev. at first max.', 'largest dev. before it ($t$)', 'first quantum min., $t$', '$σ_{max}/ℏ_{eff}$ there'],
    sm_table_w=[900, 1000, 1000, 1350, 1800, 1500, 1476], chaos=ch)
# deviation at the first quantum maximum and largest deviation before it, hbar <= 0.125 (full time resolution)
out['peak'] = PEAK
out['dev_pk'] = {k: f'{100*PEAK[k]["dev_at_qpk"]:.2g}%' for k in ('0.125', '0.06', '0.03')}
out['dev_pre'] = {k: f'{100*PEAK[k]["max_dev_before"]:.2f}%' for k in ('0.125', '0.06', '0.03')}
out['dev_peak'] = f'{100*max(PEAK[k]["dev_at_qpk"] for k in ("0.125", "0.06", "0.03")):.2f}%'
out['dev_pre_max'] = f'{100*max(PEAK[k]["max_dev_before"] for k in ("0.125", "0.06", "0.03")):.1f}%'
mu02, mu85 = 0.049942, 0.208216
out['slope02'] = f'{mu02*np.polyfit(np.log(1/h), tb, 1)[0]:.2f}'
if ch:
    hc = np.array([x[0] for x in ch]); tc = np.array([x[1] for x in ch])
    out['slope085'] = f'{mu85*np.polyfit(np.log(1/hc), tc, 1)[0]:.2f}'; out['tb085'] = fmt_list(tc)
out['rms_pow'] = f'{rms_pow:.1f}'; out['rms_log'] = f'{rms_log:.1f}'; out['mcu'] = MCU; out['chaos_tb_seeds'] = CH_TB; out['ch_tb4_025'] = CH4 if 'CH4' in globals() else None
json.dump(out, open('../ms2/longtime_vals_auto.json', 'w'), indent=1, ensure_ascii=False)
json.dump(F4, open('fig4data.json', 'w'))
print(json.dumps({k: v for k, v in out.items() if k not in ('sm_table',)}, indent=1, ensure_ascii=False))
