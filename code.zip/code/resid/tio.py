"""Load (t, s) from an .npz result. Every series is returned with the time at the end of the step that produced each
recorded state. Files without a 'tlabel' entry store the start time of that step, and load() adds one time step."""
import numpy as np
STEP = {'long_q': 1.5e-3, 'long_c': 1.5e-3, 'longconv_q': 0.75e-3, 'longconv_c': 1.5e-3, 'longmc_': 6e-3, 'longmc2': 6e-3,
          'chaos_q': 1.5e-3, 'chaos_c': 3e-3, 'traj': 1.5e-3}
def load(fname):
    z = np.load(fname); t = z['t'] if 't' in z.files else z['tq']; s = z['s']
    if 'tlabel' not in z.files:
        base = fname.split('/')[-1]
        dt = next(v for k, v in STEP.items() if base.startswith(k)); t = t + dt
    return t, s
