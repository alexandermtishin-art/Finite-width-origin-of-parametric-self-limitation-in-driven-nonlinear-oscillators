"""Tables of the Supplementary Material, from early.json, states.json, collapse.json, conv.json, hierarchy_*.json, cos and long-time data."""
import json
E=json.load(open('early.json')); S=json.load(open('states.json')); C=json.load(open('conv.json')); H=json.load(open('hierarchy_cos.json'))
HS=json.load(open('hierarchy_squeezed.json')); col=json.load(open('collapse.json'))
K={k:dict(k1=-v['g1']/(2*v['F0']),k2=v['c2']/v['F0']) for k,v in H.items()}
RICH=4.0/3.0
ERR={ser:{hb:RICH*abs(v) for hb,v in d.items()} for ser,d in C['dt'].items()}
def rr(ratio,d,err):
    e=err/abs(d)*ratio
    if e>=0.01: return f'{ratio:.2f} ± {e:.2f}'
    if e>=0.001: return f'{ratio:.3f} ± {e:.3f}'
    return f'{ratio:.3f} ± <0.001'
yn=lambda v: 'yes' if v['ok'] else 'no'
T={}
k2=K['kerr_0.2']['k2']
T['kerr02']=[[hb,f"{float(hb)/24:.5f}",f"{v['q']:.4f}",f"{v['c']:.4f}",f"{v['d']:.2e}",rr(v['d']/(k2*(float(hb)/24)**2),v['d'],ERR['kerr_0.2'][hb]),f"{v['r2']:.5f}",f"{v['sp']:.3f}"]
             for hb,v in sorted(E['kerr']['0.2'].items(),key=lambda x:-float(x[0]))]
T['kerrA_fix']=[[A,hb,f"{v['d']:.2e}",rr(v['d']/(K[f'kerr_{A}']['k2']*(float(hb)/24)**2),v['d'],ERR[f'kerr_{A}'][hb]),f"{v['r2']:.4f}",f"{v['sp']:.3f}",yn(v)]
                for A in ('0.1','0.4') for hb,v in sorted(E['kerr'][A].items(),key=lambda x:-float(x[0]))]
kc=K['cos_0.2']['k2']
T['cos']=[[hb,f"{v['q']:.4f}",f"{v['c']:.4f}",f"{v['d']:.2e}",rr(v['d']/(kc*(float(hb)/24)**2),v['d'],ERR['cos_0.2'][hb]),f"{v['r2']:.5f}",f"{v['sp']:.3f}"]
          for hb,v in sorted(E['cos'].items(),key=lambda x:-float(x[0]))]
names={'vac_wigner':'Wigner, vacuum','vac_husimi':'Husimi, vacuum','vac_disk':'disk, $⟨u⟩$ = 1','vac_ring':'ring, $u$ = 1','vac_originring':'point + ring (1, 2)',
 'f1_wigner':'signed Wigner, $|1⟩$','f1_gauss':'Gaussian, $⟨u⟩$ = 3','f1_disk':'disk, $⟨u⟩$ = 3','f1_ring':'ring, $u$ = 3','f1_tworing':'two rings (3, 10)'}
T['collapse']=[[names[k],f"{e['m1']:g}",f"{e['m2']:.4g}"]+[(f"{e['rel'][x]:.4f}" if e['ok'][x] else f"{e['rel'][x]:.4f}*") for x in sorted(e['rel'],key=float,reverse=True)] for k,e in col.items()]
T['collapse_failed']=[(names[k],x,round(e['r2'][x],4),round(e['sp'][x],3)) for k,e in col.items() for x in e['rel'] if not e['ok'][x]]
lab={'vacuum':'vacuum','fock1':'|1⟩','thermal_N8':'thermal, $n̄$ = 0.5, $n$ ≤ 8','thermal_N20':'thermal, $n̄$ = 0.5, $n$ ≤ 20'}
T['states']=[[lab[k],hb,f"{S[hb][k]['q']:.4f}",f"{S[hb][k]['c']:.4f}",f"{S[hb][k]['d']:.2e}",rr(S[hb][k]['d']/(k2*(float(hb)/24)**2),S[hb][k]['d'],RICH*abs(S[hb][k]['ddt']))] for k in lab for hb in ('0.25','0.125')]
rows=[]
for r in ('0.35','-0.35'):
    pr=HS[r]
    for hb in ('0.25','0.125'):
        v=S[hb][f'squeezed_{float(r)}']; chi=float(hb)/24
        rows.append([('x' if float(r)>0 else 'p')+f"-squeezed, r = {abs(float(r))}",hb,f"{v['lharm_rel']:.3f}",f"{v['q']:.3f}",f"{v['c']:.3f}",f"{1+pr['g1']*chi/pr['F0']:.3f}",f"{v['d']:.4f}",f"{pr['c2']*chi**2/pr['F0']:.4f}"])
T['squeezed']=rows
json.dump(T,open('../ms2/sm_tables.json','w'),indent=1,ensure_ascii=False)
print('failed collapse points:',T['collapse_failed'])
