#!/bin/bash
# Reproduces every number, table and figure of the manuscript and Supplementary Material from an empty results folder.
# Run from this directory (python3 with numpy, scipy, matplotlib). Approximate single-core times in brackets.
set -e
# --- early-time rates (Secs. II-IV, Figs. 1-3, Tables I, II, S1-S7)
python3 floquet.py                 # exact Floquet exponents (seconds)
python3 hier_cos.py                # moment hierarchy: kappa1, kappa2 for Kerr, cosine, squeezed (1 min)
python3 p01_early.py               # Kerr A = 0.1, 0.2, 0.4 and cosine well, vacuum, fixed window -> early.json (10 min)
python3 p02_conv.py                # grid, step and quadrature convergence -> conv.json (5 min)
python3 p03_states.py              # |1>, thermal (n <= 8 and n <= 20), squeezed -> states.json (10 min)
python3 collapse.py                # ten classical distributions, five widths -> collapse.json (10 min)
python3 rwa_check.py               # rotating-wave comparison -> rwa_check.json (2 min)
python3 a0ctrl.py                  # undriven control -> a0ctrl.json (1 min)
python3 fig1data.py                # harmonic validation against the Floquet exponent -> fig1data.json (5 min)
# --- long times (Sec. V, Fig. 4, Table S8)
python3 longtime.py q 0.5 0.25 0.125 0.06 0.03     # quantum to t = 250 -> long_q_*.npz (10 min)
python3 longtime.py c 0.5 0.25 0.125 0.06 0.03     # 64^2 quadrature (used for r(t) at t <= 26) -> long_c_*.npz (30 min)
python3 longconv.py q 0.06 0.03; python3 longconv2.py   # long-time convergence: M = 8192 and dt/2 (quantum), 128^2 nodes (classical) (60 min)
python3 longmc2.py 40000 0.5 0.25 0.125 0.06 0.03 # standardized Monte Carlo, N = 4e4, seed 11 (40 min)
python3 longmc2.py 40000 seed=2 0.125 0.06 0.03; python3 longmc2.py 40000 seed=3 0.125 0.06 0.03   # independent samples for the sampling uncertainty (60 min)
python3 longchaos.py 0.85 q 0.5 0.25 0.125 0.06 0.03   # A = 0.85, quantum (30 min)
python3 longchaos2.py 0.85 40000 11 0.5 0.25 0.125 0.06 0.03; python3 longchaos2.py 0.85 40000 2 0.5 0.25 0.125 0.06 0.03   # A = 0.85, standardized Monte Carlo, two samples (70 min)
python3 rcollapse.py               # r(t) numerics vs hierarchy -> rcollapse.json
python3 lyap.py 500; python3 lyap.py 2000; python3 lyapA.py 1000 0.4; python3 lyapA.py 1000 0.85   # Lyapunov exponents (30 min)
python3 longtime_vals.py           # long-time numbers -> ../ms2/longtime_vals_auto.json, fig4data.json
# --- escape (Supplement S6, Fig. S1)
python3 escape_map.py; python3 escape_time.py 0.125   # (40 min)
# --- tables and figures
python3 ms_numbers2.py; python3 sm_tables.py
cd ../figs && python3 fig1.py && python3 fig2.py && python3 fig3.py && python3 fig4.py && python3 figS1.py && cd ../ms2 && python3 merge_vals.py
# --- documents (requires node with the docx package): manuscript, Supplementary Material, response letter
node build3.js && node build_sm.js && node build_resp.js
