"""Escape from the driven cosine well vs observation time: escaped fraction of the vacuum-Wigner ensemble at T = 60, 200, 400."""
import numpy as np, json, sys
from escape_map import ensemble
hb=float(sys.argv[1]); As=np.round(np.arange(0.30,0.851,0.05),2); dt=4e-3; Tmax=400.0; Ts=(60.0,200.0,400.0)
x0,p0,W=ensemble(hb); n=len(x0)
A=np.repeat(As,n); x=np.tile(x0,len(As)); p=np.tile(p0,len(As)); tesc=np.full(x.size,np.inf)
f=lambda x,t: -(1+A*np.cos(2*t))*np.sin(x); t=0.0
for i in range(int(Tmax/dt)):
    k1x,k1p=p,f(x,t); k2x,k2p=p+dt/2*k1p,f(x+dt/2*k1x,t+dt/2); k3x,k3p=p+dt/2*k2p,f(x+dt/2*k2x,t+dt/2); k4x,k4p=p+dt*k3p,f(x+dt*k3x,t+dt)
    x=x+dt/6*(k1x+2*k2x+2*k3x+k4x); p=p+dt/6*(k1p+2*k2p+2*k3p+k4p); t+=dt
    new=(np.abs(x)>np.pi)&np.isinf(tesc); tesc[new]=t
tesc=tesc.reshape(len(As),n)
out={'hb':hb,'As':As.tolist(),'P':{str(T):[float(W[tesc[j]<=T].sum()) for j in range(len(As))] for T in Ts}}
print(json.dumps(out)); json.dump(out,open(f'escape_time_{hb}.json','w'))
