"""Classical escape map for the cosine (escape) platform V = -Omega^2(t) cos x, Omega^2 = 1 + A cos 2t.
Vacuum-Wigner ensemble (Var = hbar/2), polar quadrature; escape = trajectory reaches |x| > pi before T.
Returns the escaped weight fraction P_esc(A, hbar)."""
import numpy as np, json
from numpy.polynomial.laguerre import laggauss

def ensemble(hb, nr=32, na=96):
    z, w = laggauss(nr); th = 2*np.pi*np.arange(na)/na
    U, TH = np.meshgrid(z, th, indexing='ij'); W = np.repeat(w[:, None], na, 1).ravel(); W /= W.sum()
    rho = np.sqrt(hb*U).ravel(); return rho*np.cos(TH.ravel()), rho*np.sin(TH.ravel()), W

def p_escape(A, hb, T=60.0, dt=4e-3):
    x, p, W = ensemble(hb); esc = np.zeros_like(x, bool)
    f = lambda x, t: -(1+A*np.cos(2*t))*np.sin(x)
    t = 0.0
    for _ in range(int(T/dt)):
        k1x, k1p = p, f(x, t); k2x, k2p = p+dt/2*k1p, f(x+dt/2*k1x, t+dt/2)
        k3x, k3p = p+dt/2*k2p, f(x+dt/2*k2x, t+dt/2); k4x, k4p = p+dt*k3p, f(x+dt*k3x, t+dt)
        x = x+dt/6*(k1x+2*k2x+2*k3x+k4x); p = p+dt/6*(k1p+2*k2p+2*k3p+k4p); t += dt
        esc |= np.abs(x) > np.pi
    return float(W[esc].sum())

if __name__ == '__main__':
    As = [round(a, 2) for a in np.arange(0.10, 0.851, 0.05)]
    hbs = [1.0, 0.5, 0.25, 0.125, 0.06]
    out = []
    for hb in hbs:
        row = [p_escape(A, hb) for A in As]
        out.append(dict(hb=hb, chi=hb/24, As=As, P=row)); print(hb, [round(v, 3) for v in row], flush=True)
    json.dump(out, open('escape_map.json', 'w'))
