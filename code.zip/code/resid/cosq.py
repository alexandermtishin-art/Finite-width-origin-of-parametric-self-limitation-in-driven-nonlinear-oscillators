"""Cosine well V = -Omega^2(t) cos x at A = 0.2: quantum vs Wigner transport on the fixed window [3.12, 7.69].
Tests the sign rule of the hierarchy: classical O(chi) term flips sign with c4, quantum O(chi^2) term stays positive."""
import numpy as np, json
from numpy.polynomial.hermite_e import hermegauss
from SM_grid_engine import make_grid, potential, covariance_top_eigenvalue, h_window
import resid as R
A, dt, rec, T = 0.2, 1.5e-3, 8, 9.0
def quantum(hb, L=24.0, M=4096):
    x, dx, k = make_grid(L, M); psi = np.exp(-x**2/(2*hb)).astype(complex); psi /= np.sqrt(np.sum(abs(psi)**2)*dx)
    eK = np.exp(-1j*hb*0.5*k**2*dt); ts = []; sig = []
    for i in range(int(T/dt)):
        t = i*dt; hV = np.exp(-1j*potential('transmon', x, 1+A*np.cos(2*(t+dt/2)), 0)/hb*dt/2)
        psi = hV*psi; psi = np.fft.ifft(eK*np.fft.fft(psi)); psi = hV*psi
        if (i+1) % rec == 0: ts.append(t+dt); sig.append(covariance_top_eigenvalue(x, dx, k, psi, hb))
    return np.array(ts), np.array(sig)
def classical(hb, nq=64):
    z, w = hermegauss(nq); w = w/w.sum(); X, P = np.meshgrid(z, z); W = np.outer(w, w).ravel()
    s = np.sqrt(hb/2); x = s*X.ravel(); p = s*P.ravel()
    f = lambda x, t: -(1+A*np.cos(2*t))*np.sin(x); ts = []; sig = []
    for i in range(int(T/dt)):
        t = i*dt
        k1x, k1p = p, f(x, t); k2x, k2p = p+dt/2*k1p, f(x+dt/2*k1x, t+dt/2)
        k3x, k3p = p+dt/2*k2p, f(x+dt/2*k2x, t+dt/2); k4x, k4p = p+dt*k3p, f(x+dt*k3x, t+dt)
        x = x+dt/6*(k1x+2*k2x+2*k3x+k4x); p = p+dt/6*(k1p+2*k2p+2*k3p+k4p)
        if (i+1) % rec == 0:
            mx = W@x; mp = W@p; Vx = W@(x-mx)**2; Vp = W@(p-mp)**2; C = W@((x-mx)*(p-mp))
            ts.append(t+dt); sig.append(0.5*(Vx+Vp)+np.sqrt(0.25*(Vx-Vp)**2+C**2))
    return np.array(ts), np.array(sig)
if __name__ == '__main__':
    h = h_window(A, 3.12, 7.69, n=20001); out = []
    for hb in (0.5, 0.35, 0.25, 0.18, 0.125, 0.09, 0.06, 0.045, 0.03):
        tq, sq = quantum(hb); tc, sc = classical(hb)
        lq = R.fit(tq, sq, 3.12, 7.69); lc = R.fit(tc, sc, 3.12, 7.69)
        r = dict(hb=hb, Fq=lq[0]/h, Fc=lc[0]/h, spq=lq[2], spc=lc[2]); out.append(r); print(r, flush=True)
        json.dump(out, open('cos_fixedwin.json', 'w'), indent=1)
