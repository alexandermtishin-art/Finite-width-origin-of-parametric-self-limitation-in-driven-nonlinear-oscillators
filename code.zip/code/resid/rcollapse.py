import numpy as np, json, resid as R, hierarchy as Hh, tio
A=0.2; T=120; ts=Hh.rec_times(T)
y=Hh.evolve(A,Hh.iso(1,2),T,ts); C0=y[0:3]; C1=y[8:11]; Cq=y[16:19]
eps=1e-4
s_cl=Hh.top(*(C0+eps*C1)); s_q=Hh.top(*(C0+eps*C1+eps**2*Cq))
t_sm,scl=R.smooth(ts,s_cl); _,sq=R.smooth(ts,s_q)
r_th=(sq/scl-1)/eps**2
out={'t':t_sm[::10].tolist(),'r_th':r_th[::10].tolist(),'num':{}}
for hb in [0.5,0.25,0.125,0.06,0.03]:
    chi=hb/24
    tq,Sq=R.smooth(*tio.load(f'long_q_{hb}.npz')); tc,Sc=R.smooth(*tio.load(f'long_c_{hb}.npz'))
    Sc=np.interp(tq,tc,Sc); tc=tq
    m=tq<=T; rn=(Sq[m]/Sc[m]-1)/chi**2
    out['num'][hb]={'t':tq[m][::10].tolist(),'r':rn[::10].tolist()}
    for tt in [5,10,20,30,40]:
        j=np.argmin(abs(tq-tt)); k=np.argmin(abs(t_sm-tt)); print(hb,tt,'num',round(rn[j],1),'th',round(r_th[k],1))
json.dump(out,open('rcollapse.json','w'))
