import numpy as np
def rings(hb, us, ws, na=96):
    th = 2*np.pi*np.arange(na)/na; X = []; P = []; W = []
    for u, w in zip(us, ws):
        rho = np.sqrt(hb*u); X += list(rho*np.cos(th)); P += list(rho*np.sin(th)); W += [w/na]*na
    return np.array(X), np.array(P), np.array(W)
def originring(hb):
    X0, P0, W0 = rings(hb, [2], [0.5])
    return np.concatenate([X0, [0.0]]), np.concatenate([P0, [0.0]]), np.concatenate([W0, [0.5]])
