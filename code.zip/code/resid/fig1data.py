import numpy as np, json, resid as R
from floquet import mu
out=[]; R.beta=0.0
for A in [0.08,0.14,0.20,0.28,0.40,0.55,0.70,0.85]:
    R.A=A; R.Twin=30.0
    tq,sq=R.quantum(1.0,'vac'); tc,sc=R.classical(1.0,nq=16)
    tsm,sm=R.smooth(tq,sq); j=np.argmax(sm>12.0) if (sm>12.0).any() else len(sm)-1   # stay well inside the grid (sqrt(12)~3.5 << L=24)
    t0,t1=3.12,tsm[j]
    lq=R.fit(tq,sq,t0,t1)[0]; lc=R.fit(tc,sc,t0,t1)[0]; m=mu(A)
    r=dict(A=A,mu=m,lq=lq,lc=lc,relq=lq/m-1,relc=lc/m-1,t1=t1); out.append(r); print(json.dumps(r),flush=True)
json.dump(out,open('fig1data.json','w'))
