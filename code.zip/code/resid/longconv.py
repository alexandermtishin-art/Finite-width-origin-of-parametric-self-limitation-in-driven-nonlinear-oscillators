import numpy as np, sys, resid as R
mode=sys.argv[1]; hbs=[float(h) for h in sys.argv[2:]]
R.A=0.2; R.Twin=250.0
for hb in hbs:
    if mode=='q':
        R.dt=0.75e-3; R.rec=16
        t,s=R.quantum(hb,'vac',L=24.0,M=8192); np.savez(f'longconv_q_{hb}.npz',t=t,s=s,tlabel='end')
    else:
        t,s=R.classical(hb,nq=128); np.savez(f'longconv_c_{hb}.npz',t=t,s=s,tlabel='end')
    print(mode,hb,'done',flush=True)
