"""Initial-state generalisation (Referee 2 and beyond), Kerr platform, A = 0.20.

Quantum: grid split-operator from an arbitrary pure state; mixed states as Fock mixtures
(moments combined before the covariance eigenvalue is taken).
Classical: deterministic weighted quadrature of a phase-space distribution, propagated by
Liouville (RK4); weights may be negative (signed Wigner function of a Fock state).
All F values are taken on ONE common window per comparison (the W3 window of the quantum
state being compared), with the same <h>.
"""
import numpy as np, json, sys
from numpy.polynomial.laguerre import laggauss
from numpy.polynomial.legendre import leggauss
from numpy.polynomial.hermite_e import hermegauss
from scipy.special import eval_hermite, gammaln
from SM_grid_engine import make_grid, potential, h_window
import resid as R

A, beta, wp, Twin, dt, rec = 0.20, 1.0/6.0, 2.0, 30.0, 1.5e-3, 8
L, M = 24.0, 4096

# ---------------- quantum: raw moments vs time
def q_moments(psi, hb):
    x, dx, k = make_grid(L, M)
    psi = psi/np.sqrt(np.sum(np.abs(psi)**2)*dx)
    eK = np.exp(-1j*hb*0.5*k**2*dt)
    out = []; ts = []
    for i in range(int(Twin/dt)):
        t = i*dt
        hV = np.exp(-1j*potential('kerr', x, 1+A*np.cos(wp*(t+dt/2)), beta)/hb*dt/2)
        psi = hV*psi; psi = np.fft.ifft(eK*np.fft.fft(psi)); psi = hV*psi
        if (i+1) % rec == 0:
            d = np.abs(psi)**2*dx
            ph = np.fft.fft(psi); Np = np.sum(np.abs(ph)**2)
            pp = np.fft.ifft(hb*k*ph)
            ex = d@x; ex2 = d@x**2
            ep = hb*np.sum(np.abs(ph)**2*k)/Np; ep2 = hb**2*np.sum(np.abs(ph)**2*k**2)/Np
            exp_ = np.sum(np.conj(psi)*x*pp).real*dx      # Re<x p> = symmetrised <(xp+px)/2>
            out.append([ex, ep, ex2, ep2, exp_]); ts.append(t+dt)
    return np.array(ts), np.array(out)

def top_eig(mom):
    ex, ep, ex2, ep2, exp_ = mom.T
    Vx = ex2-ex**2; Vp = ep2-ep**2; C = exp_-ex*ep
    return 0.5*(Vx+Vp)+np.sqrt(0.25*(Vx-Vp)**2+C**2)

def fock(n, hb):
    x, dx, k = make_grid(L, M); s = x/np.sqrt(hb)
    lognorm = -0.5*(n*np.log(2)+gammaln(n+1))
    return (np.exp(lognorm)*eval_hermite(n, s)*np.exp(-s**2/2)).astype(complex)

def gauss_state(hb, r):        # r>0: x squeezed; r<0: p squeezed
    x, dx, k = make_grid(L, M)
    return np.exp(-x**2/(2*hb*np.exp(-2*r))).astype(complex)

# ---------------- classical weighted quadrature
def c_sigma(x, p, W):
    W = W/W.sum()
    def f(x, t): return -(1+A*np.cos(wp*t))*x-beta*x**3
    ts = []; sig = []
    for i in range(int(Twin/dt)):
        t = i*dt
        k1x, k1p = p, f(x, t)
        k2x, k2p = p+dt/2*k1p, f(x+dt/2*k1x, t+dt/2)
        k3x, k3p = p+dt/2*k2p, f(x+dt/2*k2x, t+dt/2)
        k4x, k4p = p+dt*k3p, f(x+dt*k3x, t+dt)
        x = x+dt/6*(k1x+2*k2x+2*k3x+k4x); p = p+dt/6*(k1p+2*k2p+2*k3p+k4p)
        if (i+1) % rec == 0:
            mx = W@x; mp = W@p; Vx = W@(x-mx)**2; Vp = W@(p-mp)**2; C = W@((x-mx)*(p-mp))
            ts.append(t+dt); sig.append(0.5*(Vx+Vp)+np.sqrt(0.25*(Vx-Vp)**2+C**2))
    return np.array(ts), np.array(sig)

def polar(hb, kind, par=None, nr=48, na=96):
    """Isotropic distribution in u = (x^2+p^2)/hb, angle uniform."""
    th = 2*np.pi*np.arange(na)/na
    if kind == 'exp':                 # density ∝ exp(-u/s), <u> = s  (vacuum s=1, Husimi s=2, thermal s=2nbar+1)
        z, w = laggauss(nr); u = par*z; wu = w
    elif kind == 'fock1':             # signed Wigner of |1>: ∝ (2u-1) e^{-u}
        z, w = laggauss(nr); u = z; wu = w*(2*z-1)
    elif kind == 'disk':              # uniform in u on [0, 2s]  (<u> = s)
        z, w = leggauss(nr); u = par*(z+1); wu = w
    elif kind == 'ring':              # u = s exactly
        u = np.array([par]); wu = np.array([1.0])
    U, TH = np.meshgrid(u, th, indexing='ij'); Wt = np.repeat(wu[:, None], na, 1)
    rho = np.sqrt(hb*U); return (rho*np.cos(TH)).ravel(), (rho*np.sin(TH)).ravel(), Wt.ravel()

def gh_gauss(hb, r, nq=64):
    z, w = hermegauss(nq); X, P = np.meshgrid(z, z, indexing='ij'); W = np.outer(w, w)
    sx = np.sqrt(hb/2)*np.exp(-r); sp = np.sqrt(hb/2)*np.exp(r)
    return (sx*X).ravel(), (sp*P).ravel(), W.ravel()

def F_on(ts, sig, t0, t1):
    h = h_window(A, t0, t1, n=20001); l, r2, sp = R.fit(ts, sig, t0, t1); return l/h, r2, sp

if __name__ == '__main__':
    hb = float(sys.argv[1]); part = sys.argv[2]
    res = {}
    if part == 'fock':          # quantum Fock runs n = 0..8 (vacuum, |1>, thermal mixture)
        for n in range(9):
            ts, mom = q_moments(fock(n, hb), hb); np.save(f'qfock_{hb}_{n}.npy', mom)
        np.save(f'qts.npy', ts); print('fock done', flush=True)
    elif part == 'sq':
        for r in (0.35, -0.35):
            ts, mom = q_moments(gauss_state(hb, r), hb); np.save(f'qsq_{hb}_{r}.npy', mom)
        print('sq done', flush=True)
