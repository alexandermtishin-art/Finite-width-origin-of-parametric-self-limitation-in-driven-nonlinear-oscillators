import numpy as np, resid as R
R.A=0.2; R.Twin=110.0
for hb in (0.5,0.25,0.125):
    t,s=R.classical(hb,nq=128); np.savez(f'longconv_c_{hb}.npz',t=t,s=s,tlabel='end'); print('c',hb,'done',flush=True)
