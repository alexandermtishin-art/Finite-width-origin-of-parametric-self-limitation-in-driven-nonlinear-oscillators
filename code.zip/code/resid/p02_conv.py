"""Numerical convergence of Delta = (lambda_qm - lambda_cl)/lambda_harm on the fixed window.
(i) Time step halved (dt = 0.75e-3, recording every 16 steps, so recording times and smoothing are physically identical)
    for EVERY point of every series in early.json (Kerr A = 0.1, 0.2, 0.4; cosine A = 0.2) and states.json is handled in p03.
(ii) Grid L = 32, M = 8192 and quadrature 96^2 at Kerr A = 0.2, hbar = 0.25 and 0.03.
Output: conv.json  {series: {hbar: dDelta_dt}, 'grid': {...}}"""
import numpy as np, json, resid as R, cosq as C
E = json.load(open('early.json'))
def kerr_delta(A, hb, dt=1.5e-3, rec=8, L=24.0, M=4096, nq=64):
    w = (3.12, 3.12 + 0.914/A); R.A, R.Twin, R.dt, R.rec = A, w[1] + 1.0, dt, rec
    tq, sq = R.quantum(hb, 'vac', L=L, M=M); tc, sc = R.classical(hb, nq=nq)
    R.dt, R.rec = 1.5e-3, 8
    return (R.fit(tq, sq, *w)[0] - R.fit(tc, sc, *w)[0])/E['lharm'][str(A)]
def cos_delta(hb, dt=1.5e-3, rec=8):
    w = (3.12, 7.69); C.T, C.dt, C.rec = w[1] + 1.0, dt, rec
    tq, sq = C.quantum(hb); tc, sc = C.classical(hb)
    C.dt, C.rec = 1.5e-3, 8
    return (R.fit(tq, sq, *w)[0] - R.fit(tc, sc, *w)[0])/E['lharm']['0.2']
out = {'dt': {}, 'grid': {}}
for A in ('0.2', '0.1', '0.4'):
    out['dt'][f'kerr_{A}'] = {}
    for hb in E['kerr'][A]:
        d1 = E['kerr'][A][hb]['d']; d2 = kerr_delta(float(A), float(hb), dt=0.75e-3, rec=16)
        out['dt'][f'kerr_{A}'][hb] = d2 - d1; print('kerr', A, hb, d1, d2 - d1, flush=True)
        json.dump(out, open('conv.json', 'w'), indent=1)
out['dt']['cos_0.2'] = {}
for hb in E['cos']:
    d1 = E['cos'][hb]['d']; d2 = cos_delta(float(hb), dt=0.75e-3, rec=16)
    out['dt']['cos_0.2'][hb] = d2 - d1; print('cos', hb, d1, d2 - d1, flush=True)
    json.dump(out, open('conv.json', 'w'), indent=1)
for hb in ('0.25', '0.03'):
    d1 = E['kerr']['0.2'][hb]['d']
    out['grid'][hb] = dict(L32_M8192=kerr_delta(0.2, float(hb), L=32.0, M=8192) - d1, nq96=kerr_delta(0.2, float(hb), nq=96) - d1)
    print('grid', hb, out['grid'][hb], flush=True)
json.dump(out, open('conv.json', 'w'), indent=1)
