"""Classical (Wigner-transport) Monte Carlo at drive amplitude A to T = 120 with the sample standardized to the exact vacuum
covariance, as in longmc2.py.  Usage: python3 longchaos2.py A N seed hbar1 hbar2 ...  -> chaos_c2_{A}_{hb}_seed{seed}.npz"""
import numpy as np, sys
A = float(sys.argv[1]); N = int(sys.argv[2]); SEED = int(sys.argv[3]); hbs = [float(h) for h in sys.argv[4:]]
beta = 1/6; dt = 3e-3; rec = 4; T = 120.0
for hb in hbs:
    rng = np.random.default_rng(SEED); z = rng.normal(size=(2, N)); z -= z.mean(1, keepdims=True)
    L = np.linalg.cholesky(np.cov(z)); z = np.linalg.solve(L, z)          # exact zero mean, unit covariance
    s = np.sqrt(hb/2); x = s*z[0]; p = s*z[1]
    f = lambda x, t: -(1 + A*np.cos(2*t))*x - beta*x**3; ts = []; sig = []
    for i in range(int(T/dt)):
        t = i*dt
        k1x, k1p = p, f(x, t); k2x, k2p = p + dt/2*k1p, f(x + dt/2*k1x, t + dt/2); k3x, k3p = p + dt/2*k2p, f(x + dt/2*k2x, t + dt/2); k4x, k4p = p + dt*k3p, f(x + dt*k3x, t + dt)
        x = x + dt/6*(k1x + 2*k2x + 2*k3x + k4x); p = p + dt/6*(k1p + 2*k2p + 2*k3p + k4p)
        if (i+1) % rec == 0:
            Vx = x.var(); Vp = p.var(); C = np.mean(x*p) - x.mean()*p.mean(); ts.append(t + dt); sig.append(0.5*(Vx + Vp) + np.sqrt(0.25*(Vx - Vp)**2 + C**2))
    np.savez(f'chaos_c2_{A}_{hb}_seed{SEED}.npz', t=np.array(ts), s=np.array(sig), tlabel='end', N=N); print('done', A, hb, SEED, flush=True)
