"""Moment hierarchy for the Kerr and cosine wells with a general anharmonic factor k(t): k = 1 (Kerr), k = -Omega^2(t) (cosine)."""
import numpy as np, json, hierarchy as H, resid as R
from scipy.integrate import solve_ivp
from SM_grid_engine import h_window
def rhs(t,y,A,kind):
    O2=1+A*np.cos(2*t); k={'kerr':1.0,'cos':-O2,'soft':-1.0,'mod':-A*np.cos(2*t)}[kind]
    X2,XP,P2=y[0:3]; X4,X3P,X2P2,XP3,P4=y[3:8]; X2_1,XP_1,P2_1=y[8:11]; q4,q3,q22,q13,q04=y[11:16]; X2_q,XP_q,P2_q=y[16:19]
    d=np.zeros(19)
    d[0]=2*XP; d[1]=P2-O2*X2; d[2]=-2*O2*XP
    d[3]=4*X3P; d[4]=3*X2P2-O2*X4; d[5]=2*XP3-2*O2*X3P; d[6]=P4-3*O2*X2P2; d[7]=-4*O2*XP3
    d[8]=2*XP_1; d[9]=P2_1-O2*X2_1-4*k*X4; d[10]=-2*O2*XP_1-8*k*X3P
    d[11]=4*q3; d[12]=3*q22-O2*q4; d[13]=2*q13-2*O2*q3; d[14]=q04-3*O2*q22+6*k*X2; d[15]=-4*O2*q13+24*k*XP
    d[16]=2*XP_q; d[17]=P2_q-O2*X2_q-4*k*q4; d[18]=-2*O2*XP_q-8*k*q3
    return d
def pred(kind,A,mom,e=1e-6):
    win=(3.12,3.12+0.914/A); T=win[1]+4; ts=H.rec_times(T)
    y0=np.zeros(19); y0[0:3]=[mom['X2'],mom['XP'],mom['P2']]; y0[3:8]=[mom[k] for k in ('X4','X3P','X2P2','XP3','P4')]
    y=solve_ivp(rhs,(0,T),y0,args=(A,kind),t_eval=ts,rtol=1e-10,atol=1e-12,method='DOP853').y
    h=h_window(A,*win,n=20001); lam=lambda C: R.fit(ts,H.top(*C),*win)[0]
    l0=lam(y[0:3]); lc=lam(y[0:3]+e*y[8:11]); lq=lam(y[0:3]+e*y[8:11]+e*e*y[16:19])
    return dict(F0=l0/h,g1=(lc-l0)/e/h,c2=(lq-lc)/e**2/h)
if __name__=='__main__':
    out={}
    for kind in ('kerr','cos','soft','mod'):
        for A in (0.1,0.2,0.4):
            if kind in ('soft','mod') and A!=0.2: continue
            out[f'{kind}_{A}']=r=pred(kind,A,H.iso(1,2)); print(kind,A,r,'kappa1',-r['g1']/2/r['F0'],'kappa2',r['c2']/r['F0'],flush=True)
    json.dump(out,open('hierarchy_cos.json','w'),indent=1)
    hp={}
    for A in (0.1,0.2,0.4):
        hp[str(A)]={n:pred('kerr',A,H.iso(m1,m2)) for n,(m1,m2) in {'vacuum':(1,2),'thermal_nbar0.5':(2,8),'fock1':(3,10)}.items()}
    json.dump(hp,open('hierarchy_pred.json','w'),indent=1)
    sq={}
    for r in (0.35,-0.35):
        a=np.exp(-2*r)/2; b=np.exp(2*r)/2
        sq[str(r)]=pred('kerr',0.2,dict(X2=a,XP=0,P2=b,X4=3*a*a,X3P=0,X2P2=a*b,XP3=0,P4=3*b*b)); print(r,sq[str(r)])
    json.dump(sq,open('hierarchy_squeezed.json','w'),indent=1)
