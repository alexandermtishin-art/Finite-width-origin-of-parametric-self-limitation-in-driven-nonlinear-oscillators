"""Early-time rates on the fixed window [3.12, 3.12 + 0.914/A] for the Kerr well (A = 0.1, 0.2, 0.4) and the cosine
well (A = 0.2), vacuum initial state. Quantum: split-operator grid (midpoint potential). Classical: Gauss-Hermite 64^2.
All rates are reported relative to the harmonic rate lambda_harm on the same window, with fit statistics (W1: R^2, W2: spread).
Output: early.json"""
import numpy as np, json, sys, resid as R, cosq as C
from numpy.polynomial.hermite_e import hermegauss

def harmonic_rate(A, w):
    """lambda_harm: classical harmonic transport (exact for linear dynamics), same estimator and window."""
    R.A, b0, R.Twin = A, R.beta, w[1] + 1.0
    R.beta = 0.0; t, s = R.classical(1.0, nq=16); R.beta = b0
    return R.fit(t, s, *w)[0]

def stats(tq, sq, tc, sc, w, lh):
    lq, r2q, spq = R.fit(tq, sq, *w); lc, r2c, spc = R.fit(tc, sc, *w)
    return dict(q=lq/lh, c=lc/lh, d=(lq-lc)/lh, r2=min(r2q, r2c), sp=max(spq, spc),
                ok=bool(min(r2q, r2c) >= 0.98 and max(spq, spc) <= 0.10))

out = {'kerr': {}, 'cos': {}, 'lharm': {}}
HB = {0.2: [0.5, 0.35, 0.25, 0.18, 0.125, 0.09, 0.06, 0.045, 0.03], 0.1: [0.5, 0.25, 0.125, 0.06], 0.4: [0.5, 0.25, 0.125, 0.06]}
for A in (0.2, 0.1, 0.4):
    w = (3.12, 3.12 + 0.914/A); lh = harmonic_rate(A, w); out['lharm'][str(A)] = lh
    out['kerr'][str(A)] = {}
    for hb in HB[A]:
        R.A, R.Twin = A, w[1] + 1.0
        tq, sq = R.quantum(hb); tc, sc = R.classical(hb)
        out['kerr'][str(A)][str(hb)] = r = stats(tq, sq, tc, sc, w, lh); print('kerr', A, hb, r, flush=True)
        if A == 0.2: np.savez(f'traj_{hb}.npz', tq=tq, sq=sq, tc=tc, sc=sc)
    json.dump(out, open('early.json', 'w'), indent=1)
w = (3.12, 7.69); lh = out['lharm']['0.2']; C.T = w[1] + 1.0
for hb in HB[0.2]:
    tq, sq = C.quantum(hb); tc, sc = C.classical(hb)
    out['cos'][str(hb)] = r = stats(tq, sq, tc, sc, w, lh); print('cos', hb, r, flush=True)
    json.dump(out, open('early.json', 'w'), indent=1)
