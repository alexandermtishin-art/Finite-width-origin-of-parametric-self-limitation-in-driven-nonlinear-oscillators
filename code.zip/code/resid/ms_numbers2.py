"""Numbers quoted in the manuscript, from early.json, states.json, collapse.json, conv.json, hierarchy_cos.json."""
import json, numpy as np
E=json.load(open('early.json')); S=json.load(open('states.json')); C=json.load(open('conv.json')); H=json.load(open('hierarchy_cos.json'))
K={k:dict(k1=-v['g1']/(2*v['F0']),k2=v['c2']/v['F0']) for k,v in H.items()}
ERR={ser:{hb:4/3*abs(v) for hb,v in d.items()} for ser,d in C['dt'].items()}
out={}
for well,A in (('kerr','0.1'),('kerr','0.2'),('kerr','0.4'),('cos','0.2')):
    d=E['kerr'][A] if well=='kerr' else E['cos']; k2=K[f'{well}_{A}']['k2']
    rows=[]
    for hb,v in sorted(d.items(),key=lambda x:-float(x[0])):
        chi=float(hb)/24; ratio=v['d']/(k2*chi**2); err=ERR[f'{well}_{A}'][hb]/v['d']*ratio
        rows.append((float(hb),v['q'],v['c'],v['d'],ratio,err,v['r2'],v['sp'],v['ok']))
        print(well,A,hb,'q %.4f c %.4f d %.3e ratio %.3f ± %.3f r2 %.5f sp %.3f ok %s'%rows[-1][1:])
    ok=sorted([r for r in rows if r[8]]); loc=[(ok[i][0],ok[i+1][0],np.log(ok[i+1][3]/ok[i][3])/np.log(ok[i+1][0]/ok[i][0])) for i in range(len(ok)-1)]
    print('  local slopes',[(a,b,round(c,3)) for a,b,c in loc])
    out[f'{well}_{A}']=dict(rows=rows,local_slopes=loc,k1=K[f'{well}_{A}']['k1'],k2=k2)
allr2=[v['r2'] for A in E['kerr'] for v in E['kerr'][A].values() if v['ok']]+[v['r2'] for v in E['cos'].values() if v['ok']]+[v['r2'] for hb in S for v in S[hb].values() if v['ok']]
col=json.load(open('collapse.json')); allr2+=[e['r2'][x] for e in col.values() for x in e['r2'] if e['ok'][x]]
print('min R2 over all accepted rates', min(allr2)); out['min_r2']=min(allr2)
for hb,rows in S.items():
    for k,v in rows.items(): print('state',hb,k,'q %.4f c %.4f d %.3e r2 %.5f sp %.3f ok %s'%(v['q'],v['c'],v['d'],v['r2'],v['sp'],v['ok']), 'ratio %.3f'%(v['d']/(K['kerr_0.2']['k2']*(float(hb)/24)**2)) if not k.startswith('sq') else '')
json.dump(out,open('ms_numbers2.json','w'),indent=1)
