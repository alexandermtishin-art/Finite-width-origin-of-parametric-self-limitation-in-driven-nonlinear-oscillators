import numpy as np, sys, resid as R
mode=sys.argv[1]; hbs=[float(h) for h in sys.argv[2:]]
R.A=0.2; R.Twin=250.0
for hb in hbs:
    if mode=='q':
        t,s=R.quantum(hb,'vac'); np.savez(f'long_q_{hb}.npz',t=t,s=s,tlabel='end')
    else:
        t,s=R.classical(hb,nq=64); np.savez(f'long_c_{hb}.npz',t=t,s=s,tlabel='end')
    print(mode,hb,'done',flush=True)
