"""Closed moment hierarchy for the driven Kerr oscillator in rescaled variables (x = sqrt(hbar) X).
Classical flow: X' = P, P' = -Omega^2(t) X - 4 chi X^3.  Wigner-Moyal adds -chi X d^3_P W.

Expansion in chi:
  C   = C0 + chi C1 + chi^2 (C2_cl + C2_q) + ...
  C0  : second moments under the Mathieu flow
  M4  : fourth moments under the Mathieu flow (chi^0)
  C1  : sourced by M4 through -4 chi <X^4>, -8 chi <X^3 P>           (classical, depends on 4th moments)
  M4q : chi^1 change of 4th moments from the Moyal term, sourced by 6<X^2>, 24<XP>   (quantum)
  C2q : chi^2 change of second moments sourced by M4q                  (quantum - classical, exact at this order)
The quantum-classical difference of the second moments to O(chi^2) is chi^2 C2q, which depends only on C0,
i.e. on the initial second moments.
"""
import numpy as np, json, sys
from scipy.integrate import solve_ivp
import resid as R
from SM_grid_engine import h_window

def rhs(t, y, A, src_moyal=True):
    O2 = 1 + A*np.cos(2*t)
    X2, XP, P2 = y[0:3]; X4, X3P, X2P2, XP3, P4 = y[3:8]
    X2_1, XP_1, P2_1 = y[8:11]; q4, q3, q22, q13, q04 = y[11:16]; X2_q, XP_q, P2_q = y[16:19]
    d = np.zeros(19)
    d[0] = 2*XP; d[1] = P2 - O2*X2; d[2] = -2*O2*XP
    d[3] = 4*X3P; d[4] = 3*X2P2 - O2*X4; d[5] = 2*XP3 - 2*O2*X3P; d[6] = P4 - 3*O2*X2P2; d[7] = -4*O2*XP3
    d[8] = 2*XP_1; d[9] = P2_1 - O2*X2_1 - 4*X4; d[10] = -2*O2*XP_1 - 8*X3P
    # Moyal-sourced fourth moments (harmonic propagation + sources)
    d[11] = 4*q3; d[12] = 3*q22 - O2*q4; d[13] = 2*q13 - 2*O2*q3; d[14] = q04 - 3*O2*q22 + 6*X2; d[15] = -4*O2*q13 + 24*XP
    d[16] = 2*XP_q; d[17] = P2_q - O2*X2_q - 4*q4; d[18] = -2*O2*XP_q - 8*q3
    return d

def evolve(A, mom, T, ts):
    """mom: dict of initial moments in rescaled units: X2, XP, P2, X4, X3P, X2P2, XP3, P4."""
    y0 = np.zeros(19)
    y0[0:3] = [mom['X2'], mom['XP'], mom['P2']]; y0[3:8] = [mom['X4'], mom['X3P'], mom['X2P2'], mom['XP3'], mom['P4']]
    s = solve_ivp(rhs, (0, T), y0, args=(A,), t_eval=ts, rtol=1e-10, atol=1e-12, method='DOP853')
    return s.y

def rec_times(T, dt=1.5e-3, rec=8):
    """Record times of resid.quantum/classical: samples at t = (i+1)*dt for (i+1) % rec == 0, i.e. t = k*rec*dt, k = 1, 2, ..."""
    return rec*dt*np.arange(1, int(np.floor(T/(rec*dt) + 1e-9)) + 1)

def top(X2, XP, P2): return 0.5*(X2+P2) + np.sqrt(0.25*(X2-P2)**2 + XP**2)

def iso(m1, m2):   # isotropic distribution with <u> = m1, <u^2> = m2, u = X^2 + P^2
    return dict(X2=m1/2, XP=0, P2=m1/2, X4=3*m2/8, X3P=0, X2P2=m2/8, XP3=0, P4=3*m2/8)

def predict(A, mom, win, chi_small=1e-6, T=None):
    T = T or win[1] + 4
    ts = rec_times(T)
    y = evolve(A, mom, T, ts)
    C0 = y[0:3]; C1 = y[8:11]; Cq = y[16:19]
    h = h_window(A, win[0], win[1], n=20001)
    lam = lambda C: R.fit(ts, top(*C), win[0], win[1])[0]
    l0 = lam(C0)
    lcl = lam(C0 + chi_small*C1); lq = lam(C0 + chi_small*C1 + chi_small**2*Cq)
    g1 = (lcl - l0)/chi_small/h            # dF_cl / d chi
    c2 = (lq - lcl)/chi_small**2/h          # dF_qm-cl / chi^2
    return dict(F0=l0/h, g1=g1, c2=c2)

if __name__ == '__main__':
    out = {}
    for A in (0.1, 0.2, 0.4):
        win = (3.12, 3.12 + 0.914/A)
        out[A] = {name: predict(A, iso(m1, m2), win) for name, (m1, m2) in
                  {'vacuum': (1, 2), 'thermal_nbar0.5': (2, 8), 'fock1': (3, 10), 'disk_vac': (1, 4/3), 'ring_vac': (1, 1), 'husimi_vac': (2, 8)}.items()}
        print(A, json.dumps(out[A], indent=None))
    json.dump(out, open('hierarchy_pred.json', 'w'), indent=1)
