import numpy as np
from scipy.integrate import solve_ivp
def mu(A):
    T=np.pi
    f=lambda t,y:[y[1],-(1+A*np.cos(2*t))*y[0]]
    M=np.zeros((2,2))
    for j,y0 in enumerate([[1,0],[0,1]]):
        s=solve_ivp(f,(0,T),y0,rtol=1e-12,atol=1e-14); M[:,j]=s.y[:,-1]
    ev=np.linalg.eigvals(M); return np.log(np.max(np.abs(ev)))/T
print(" A      mu_exact   A/4      mu/(A/4)   F_harm_exact=mu/(2A/pi)")
for A in [0.08,0.10,0.14,0.20,0.28,0.40,0.55,0.70,0.85]:
    m=mu(A); print(f"{A:5.2f}  {m:.6f}  {A/4:.5f}  {m/(A/4):.5f}   {m/(2*A/np.pi):.5f}")
