"""Initial-state family on the fixed window (Kerr, A = 0.2): vacuum, Fock |1>, thermal nbar = 0.5 (Fock mixture with
n <= 8 and n <= 20, to check truncation), squeezed vacua r = +-0.35. Quantum: grid; classical: Wigner transport by quadrature.
Rates relative to lambda_harm (isotropic states) or to the harmonic rate of the squeezed state. Each state is computed with
dt = 1.5e-3 and with dt/2 (same recording times) and the change of Delta is stored as 'ddt'. Output: states.json"""
import numpy as np, json, gen as G, resid as R
w = (3.12, 7.69); G.Twin = 8.7
lh = json.load(open('early.json'))['lharm']['0.2']
nbar = 0.5
def run(hb, dt, rec):
    G.dt, G.rec = dt, rec
    ts = None; fock = {}
    for n in range(21):
        ts, mom = G.q_moments(G.fock(n, hb), hb); fock[n] = mom
    def mix(N):
        p = np.array([(1/(1+nbar))*(nbar/(1+nbar))**n for n in range(N+1)]); p /= p.sum()
        return sum(p[n]*fock[n] for n in range(N+1))
    rows = {}
    def rec_(name, qsig, csig, lref):
        lq, r2q, spq = R.fit(ts, qsig, *w); tc, sc = csig; lc, r2c, spc = R.fit(tc, sc, *w)
        rows[name] = dict(q=lq/lref, c=lc/lref, d=(lq-lc)/lref, r2=min(r2q, r2c), sp=max(spq, spc),
                          ok=bool(min(r2q, r2c) >= 0.98 and max(spq, spc) <= 0.10))
    rec_('vacuum', G.top_eig(fock[0]), G.c_sigma(*G.polar(hb, 'exp', 1.0)), lh)
    rec_('fock1', G.top_eig(fock[1]), G.c_sigma(*G.polar(hb, 'fock1')), lh)
    for N in (8, 20):
        rec_(f'thermal_N{N}', G.top_eig(mix(N)), G.c_sigma(*G.polar(hb, 'exp', 2.0)), lh)
        rows[f'thermal_N{N}']['weight_cut'] = float((nbar/(1+nbar))**(N+1))
    for r in (0.35, -0.35):
        tq, mom = G.q_moments(G.gauss_state(hb, r), hb)
        XPW = G.gh_gauss(hb, r); b0 = G.beta; G.beta = 0.0; th, sh = G.c_sigma(*XPW); G.beta = b0
        lr = R.fit(th, sh, *w)[0]
        rec_(f'squeezed_{r}', G.top_eig(mom), G.c_sigma(*XPW), lr); rows[f'squeezed_{r}']['lharm_rel'] = lr/lh
    G.dt, G.rec = 1.5e-3, 8
    return rows
out = {}
for hb in (0.25, 0.125):
    a = run(hb, 1.5e-3, 8); b = run(hb, 0.75e-3, 16)
    for k in a: a[k]['ddt'] = b[k]['d'] - a[k]['d']; print(hb, k, a[k], flush=True)
    out[str(hb)] = a
    json.dump(out, open('states.json', 'w'), indent=1)
