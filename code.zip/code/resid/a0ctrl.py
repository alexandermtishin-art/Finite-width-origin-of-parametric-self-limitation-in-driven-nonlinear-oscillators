import numpy as np, json, resid as R
R.A=0.0; R.Twin=9.0; out=[]
for hb in (0.5,0.25,0.125):
    tq,sq=R.quantum(hb); tc,sc=R.classical(hb,nq=48)
    lq=R.fit(tq,sq,3.12,7.69)[0]; lc=R.fit(tc,sc,3.12,7.69)[0]
    r=dict(hb=hb,lam_q=lq,lam_c=lc,maxdev_q=float(abs(sq/sq[0]-1).max()),maxdev_c=float(abs(sc/sc[0]-1).max())); out.append(r); print(r,flush=True)
json.dump(out,open('a0ctrl.json','w'),indent=1)
