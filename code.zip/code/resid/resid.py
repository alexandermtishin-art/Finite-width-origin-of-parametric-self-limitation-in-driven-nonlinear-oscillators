"""Deterministic quantum vs truncated-Wigner comparison for the Kerr platform.

Same model, drive, grid, time step, recording and fit routine as SM_grid_engine.py,
with two changes that remove protocol noise:
  * the classical ensemble is a Gauss-Hermite product quadrature (no random seeds);
  * both branches are fitted on ONE common window (the quantum branch's W3 window),
    with the same <h>.
Initial state options: 'vac' = harmonic vacuum Gaussian in both branches (exact match);
'gs' = Kerr ground state for the quantum branch (as in the author's code) vs vacuum Wigner.
"""
import numpy as np, json, sys
from numpy.polynomial.hermite_e import hermegauss
from SM_grid_engine import make_grid, ground_state, potential, covariance_top_eigenvalue, h_window, _eta, _Om

A, beta, wp = 0.20, 1.0/6.0, 2.0
Twin, dt, rec = 30.0, 1.5e-3, 8

def quantum(hb, init='vac', L=24.0, M=4096):
    x, dx, k = make_grid(L, M)
    if init == 'vac':
        psi = np.exp(-x**2/(2*hb)).astype(complex)
    else:
        psi = ground_state(x, dx, k, potential('kerr', x, 1.0, beta), hb)
    psi /= np.sqrt(np.sum(np.abs(psi)**2)*dx)
    eK = np.exp(-1j*hb*0.5*k**2*dt)
    n = int(Twin/dt); ts = []; sig = []
    for i in range(n):
        t = i*dt
        hV = np.exp(-1j*potential('kerr', x, 1+A*np.cos(wp*(t+dt/2)), beta)/hb*dt/2)
        psi = hV*psi; psi = np.fft.ifft(eK*np.fft.fft(psi)); psi = hV*psi
        if (i+1) % rec == 0:
            ts.append(t+dt); sig.append(covariance_top_eigenvalue(x, dx, k, psi, hb))
    return np.array(ts), np.array(sig)

def classical(hb, nq=64):
    z, w = hermegauss(nq); w = w/w.sum()
    X, P = np.meshgrid(z, z); W = np.outer(w, w).ravel()
    s = np.sqrt(hb/2); x = s*X.ravel(); p = s*P.ravel()
    def f(x, t): return -(1+A*np.cos(wp*t))*x - beta*x**3
    n = int(Twin/dt); ts = []; sig = []
    for i in range(n):
        t = i*dt
        k1x, k1p = p, f(x, t)
        k2x, k2p = p+dt/2*k1p, f(x+dt/2*k1x, t+dt/2)
        k3x, k3p = p+dt/2*k2p, f(x+dt/2*k2x, t+dt/2)
        k4x, k4p = p+dt*k3p, f(x+dt*k3x, t+dt)
        x = x+dt/6*(k1x+2*k2x+2*k3x+k4x); p = p+dt/6*(k1p+2*k2p+2*k3p+k4p)
        if (i+1) % rec == 0:
            mx = W@x; mp = W@p
            Vx = W@(x-mx)**2; Vp = W@(p-mp)**2; C = W@((x-mx)*(p-mp))
            ts.append(t+dt); sig.append(0.5*(Vx+Vp)+np.sqrt(0.25*(Vx-Vp)**2+C**2))
    return np.array(ts), np.array(sig)

def smooth(ts, sig):
    win = max(3, int(np.pi/(ts[1]-ts[0])))
    return ts[win-1:], np.convolve(sig, np.ones(win)/win, mode='valid')

def w3_window(ts, sig, tmin=2.0, frac=0.6):
    tsm, sm = smooth(ts, sig); lo = np.argmax(tsm >= tmin)
    cr = np.where(sm[lo:] > frac*sm.max())[0]
    hi = lo+cr[0] if len(cr) else len(tsm)-1
    return tsm[lo], tsm[hi-1]

def fit(ts, sig, t0, t1):
    tsm, sm = smooth(ts, sig); m = (tsm >= t0) & (tsm <= t1)
    t = tsm[m]; y = np.log(sm[m]); n = len(t)
    sl = np.polyfit(t, y, 1)[0]
    yh = np.polyval(np.polyfit(t, y, 1), t); r2 = 1-np.sum((y-yh)**2)/np.sum((y-y.mean())**2)
    s1 = np.polyfit(t[:n//2], y[:n//2], 1)[0]; s3 = np.polyfit(t[n//2:], y[n//2:], 1)[0]
    return sl/2, r2, abs(s1-s3)/abs(0.5*(s1+s3))

if __name__ == '__main__':
    init = sys.argv[1]; hbs = [float(a) for a in sys.argv[2:]]
    out = []
    for hb in hbs:
        tq, sq = quantum(hb, init); tc, sc = classical(hb)
        t0, t1 = w3_window(tq, sq); h = h_window(A, t0, t1, n=20001)
        lq, r2q, spq = fit(tq, sq, t0, t1); lc, r2c, spc = fit(tc, sc, t0, t1)
        # author's convention: each branch its own W3 window
        c0, c1 = w3_window(tc, sc); hc = h_window(A, c0, c1, n=20001); lc_own = fit(tc, sc, c0, c1)[0]
        tsm, smq = smooth(tq, sq); _, smc = smooth(tc, sc)
        ratio = smq/smc; m = (tsm >= t0) & (tsm <= t1)
        r = dict(init=init, hb=hb, win=[t0, t1], Fq=lq/h, Fc=lc/h, dF=(lq-lc)/h, r2q=r2q, spq=spq, r2c=r2c, spc=spc,
                 Fc_ownwin=lc_own/hc, win_c=[c0, c1], ratio_start=ratio[m][0], ratio_end=ratio[m][-1],
                 var0_q=float(sq[0]))
        out.append(r); print(json.dumps(r, default=float), flush=True)
    json.dump(out, open(f'resid_{init}_{"_".join(map(str,hbs))}.json', 'w'), default=float)
