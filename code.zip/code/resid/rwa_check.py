"""Is the O(chi) classical gain reduction a rotating-wave (detuning) effect?  Compare full classical Wigner
transport with the averaged (RWA) dynamics da/dt = -i[(A/4) a* + 3 chi |a|^2 a] on the same window."""
import numpy as np, json
from numpy.polynomial.hermite_e import hermegauss
import resid as R
A=0.2; dt=1.5e-3; rec=8; T=9.0; w=(3.12,7.69)
z,wq=hermegauss(48); wq/=wq.sum(); X,P=np.meshgrid(z,z); W=np.outer(wq,wq).ravel()
X=X.ravel()*np.sqrt(0.5); P=P.ravel()*np.sqrt(0.5)
def sig(x,p):
    mx=W@x; mp=W@p; Vx=W@(x-mx)**2; Vp=W@(p-mp)**2; C=W@((x-mx)*(p-mp)); return 0.5*(Vx+Vp)+np.sqrt(0.25*(Vx-Vp)**2+C**2)
def full(chi):
    x=X.copy(); p=P.copy(); f=lambda x,t: -(1+A*np.cos(2*t))*x-4*chi*x**3; ts=[]; s=[]
    for i in range(int(T/dt)):
        t=i*dt
        k1x,k1p=p,f(x,t); k2x,k2p=p+dt/2*k1p,f(x+dt/2*k1x,t+dt/2); k3x,k3p=p+dt/2*k2p,f(x+dt/2*k2x,t+dt/2); k4x,k4p=p+dt*k3p,f(x+dt*k3x,t+dt)
        x=x+dt/6*(k1x+2*k2x+2*k3x+k4x); p=p+dt/6*(k1p+2*k2p+2*k3p+k4p)
        if i%rec==0: ts.append(t); s.append(sig(x,p))
    return np.array(ts),np.array(s)
def rwa(chi):
    a=(X+1j*P)/np.sqrt(2); g=lambda a: -1j*((A/4)*np.conj(a)+3*chi*abs(a)**2*a); ts=[]; s=[]
    for i in range(int(T/dt)):
        t=i*dt; k1=g(a); k2=g(a+dt/2*k1); k3=g(a+dt/2*k2); k4=g(a+dt*k3); a=a+dt/6*(k1+2*k2+2*k3+k4)
        if i%rec==0: ts.append(t); s.append(sig(np.sqrt(2)*a.real,np.sqrt(2)*a.imag))
    return np.array(ts),np.array(s)
out={}
for name,fn in (('full',full),('rwa',rwa)):
    l0=R.fit(*fn(0.0),*w)[0]; out[name]={}
    for chi in (0.00125,0.0025,0.005,0.0104,0.0208):
        l=R.fit(*fn(chi),*w)[0]; out[name][chi]=(l-l0)/l0; print(name,chi,(l-l0)/l0,(l-l0)/l0/chi,flush=True)
json.dump(out,open('rwa_check.json','w'),indent=1)
