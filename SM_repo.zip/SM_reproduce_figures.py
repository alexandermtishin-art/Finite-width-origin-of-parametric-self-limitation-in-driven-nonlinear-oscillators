"""
Supplemental Material — Code 2 of 2
===================================================================
Reproduces Figures 1-4 of the main text by calling SM_grid_engine.py.

  Fig. 1  Engine validation: grid parametric gain vs analytic Mathieu rate A/4.
  Fig. 2  Quantum parametric gain F = lambda/<h> vs xi at hbar_eff = 1 for four
          platforms (harmonic, Kerr, hard x^6, transmon-type) -> no collapse.
  Fig. 3  Quantum-to-classical crossover: F(hbar_eff) at fixed (|U|, xi).

Run:  python SM_reproduce_figures.py
Approximate runtime: a few minutes (grid FFT propagation; no truncation).
Environment (tested): Python 3.11; numpy >= 1.24; matplotlib >= 3.7;
SM_grid_engine.py (v1.0) in the same folder.
===================================================================
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from SM_grid_engine import (make_grid, ground_state, ground_energy, run_gain,
                            secular_rate, classical_tangent, classical_ensemble,
                            eta_char, h_window)

R2_MIN, SPREAD_MAX = 0.98, 0.10          # pre-registered criteria (W1, W2)

def accepted(r2, spread):
    """Pre-registered acceptance: log-linearity AND window stability."""
    return (r2 >= R2_MIN) and (spread <= SPREAD_MAX)

U_abs = 1.0 / 24.0          # |U| = beta/4 with beta = 1/6, used for Figs 1-2
plt.rcParams.update({'font.size': 10, 'axes.linewidth': 0.9})


def fig1_validation():
    print("Fig 1: harmonic validation vs Mathieu ...")
    As = [0.08, 0.12, 0.16, 0.20]
    lam = []
    for A in As:
        ts, sig, _h = run_gain('harm', A, Twin=30.0)
        l, r2, _, _w = secular_rate(ts, sig)
        lam.append(l); print(f"   A={A}: gain={l:.4f} (A/4={A/4:.4f}) R2={r2:.3f}")
    A = np.array(As); lam = np.array(lam); th = A / 4
    fig, ax = plt.subplots(figsize=(5.0, 4.8))
    lo, hi = 0.015, 0.055
    ax.plot([lo, hi], [lo, hi], '--', color='0.45', lw=1.2, label='analytic Mathieu $A/4$')
    ax.plot(th, lam, 'o', color='#1f3b6e', ms=11, label='grid split-operator')
    ax.set_xlabel(r'analytic Mathieu rate $A/4$'); ax.set_ylabel(r'grid parametric gain $\lambda_{\rm param}$')
    ax.set_title('Engine validation (harmonic)', fontsize=10.5)
    ax.set_xlim(lo, hi); ax.set_ylim(lo, hi); ax.set_aspect('equal'); ax.grid(alpha=0.3)
    ax.set_xticks([0.02,0.03,0.04,0.05]); ax.set_yticks([0.02,0.03,0.04,0.05]); ax.tick_params(labelsize=11)
    ax.legend(loc='upper left', fontsize=9)
    fig.tight_layout(); fig.savefig('SM_fig1_validation.png', dpi=160); plt.close(fig)


def fig2_no_collapse():
    print("Fig 2: quantum gain sweep (hbar=1) ...")
    As = [0.10, 0.14, 0.20, 0.28, 0.40, 0.55, 0.70, 0.85]
    data = {p: [] for p in ['harm', 'kerr', 'hard', 'transmon']}
    xis = []
    for A in As:
        xis.append(eta_char(A) / U_abs)
        for p in data:
            LM = (48.0, 8192) if p == 'transmon' else (24.0, 4096)
            ts, sig, _h = run_gain(p, A, hbar=1.0, Twin=30.0, L=LM[0], M=LM[1])
            l, r2, sp, _w = secular_rate(ts, sig); h = h_window(A, _w[0], _w[1])
            data[p].append((l / h, r2, sp))
    xis = np.array(xis)
    fig, ax = plt.subplots(figsize=(6.6, 5.0))
    ax.axhline(0.28, ls=':', color='0.5', lw=1)
    sty = {'harm': ('#888', 'o', 'harmonic (Mathieu, linear)'),
           'kerr': ('#1f3b6e', 's', 'Kerr (confining) - self-limits'),
           'hard': ('#2a8f4e', 'D', 'hard $x^6$ (confining) - self-limits'),
           'transmon': ('#a11', '^', 'transmon-type (escape) - amplifies')}
    for p in ['harm', 'kerr', 'hard', 'transmon']:
        F = np.array([d[0] for d in data[p]]); R2 = np.array([d[1] for d in data[p]])
        SP = np.array([d[2] for d in data[p]])
        c, m, lab = sty[p]
        ax.plot(xis, F, m + '-', color=c, ms=6, lw=1.5, label=lab)
        bad = ~np.array([accepted(r, s_) for r, s_ in zip(R2, SP)])
        if bad.any(): ax.plot(xis[bad], F[bad], m, color=c, ms=10, mfc='none', mew=1.8)
    ax.set_xscale('log'); ax.set_ylim(-0.12, 0.72)
    ax.set_xlabel(r'$\xi=\eta/|U|$ (pre-registered, $|U|=1/24$)')
    ax.set_ylabel(r'$F=\lambda_{\rm param}/\langle h\rangle$')
    ax.set_title('Quantum parametric gain: platforms do NOT collapse', fontsize=10.5)
    ax.grid(alpha=0.25, which='both')
    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.14), ncol=2, fontsize=8.6)
    fig.subplots_adjust(bottom=0.30); fig.savefig('SM_fig2_no_collapse.png', dpi=160, bbox_inches='tight'); plt.close(fig)


def fig3_crossover():
    print("Fig 3: hbar crossover at fixed (|U|, xi) ...")
    A = 0.20   # xi ~ 3 at |U| = 1/24
    # Infinitesimal-perturbation reference: must use kind='harm' and a window that
    # excludes the tangent-alignment transient.
    ck, hk = classical_tangent('harm', A, Twin=200.0, tfit=40.0); Fcl = ck / hk
    hbs = [1.0, 0.5, 0.25, 0.125, 0.06]
    Fk, R2k, SPk = [], [], []
    for hb in hbs:
        ts, sig, _h = run_gain('kerr', A, hbar=hb, Twin=30.0, dt=1.5e-3, M=4096)
        l, r2, sp, _w = secular_rate(ts, sig); h = h_window(0.20, _w[0], _w[1])
        Fk.append(l / h); R2k.append(r2); SPk.append(sp)
        print(f"   hbar={hb}: F={l/h:.3f} R2={r2:.3f} spread={sp:.3f} "
              f"accepted={accepted(r2, sp)}")
    hbs = np.array(hbs); Fk = np.array(Fk); R2k = np.array(R2k); SPk = np.array(SPk)
    fig, ax = plt.subplots(figsize=(6.6, 5.0))
    ax.axhline(Fcl, ls='--', color='0.35', lw=1.2)
    ax.text(0.3, Fcl + 0.014, f'classical tangent $=${Fcl:.3f}  ($\\pi/8=0.393$)', fontsize=9, color='0.35', ha='center')
    ax.plot(hbs, Fk, 's-', color='#1f3b6e', ms=7, lw=1.6, label='Kerr (confining)')
    bad = ~np.array([accepted(r, s_) for r, s_ in zip(R2k, SPk)])
    if bad.any(): ax.plot(hbs[bad], Fk[bad], 's', color='#1f3b6e', ms=11, mfc='none', mew=1.8,
                          label='fails (W1) or (W2)')
    ax.set_xscale('log'); ax.invert_xaxis(); ax.set_ylim(-0.08, 0.42)
    ax.set_xlabel(r'$\hbar_{\rm eff}$ (larger = more quantum $\to$ smaller = more classical)')
    ax.set_ylabel(r'$F=\lambda_{\rm param}/\langle h\rangle$ at fixed $\xi\simeq3$')
    ax.set_title('Quantum-to-classical crossover of self-limitation', fontsize=10.5)
    ax.grid(alpha=0.25, which='both'); ax.legend(loc='lower left', fontsize=9)
    fig.tight_layout(); fig.savefig('SM_fig3_crossover.png', dpi=160); plt.close(fig)


def fig4_classical_vs_quantum():
    print("Fig 4: classical ensemble vs quantum (Kerr, fixed |U|, xi) ...")
    hbs = [1.0, 0.5, 0.25, 0.125, 0.06]
    Fcl, R2cl, SPcl = [], [], []
    for hb in hbs:
        ts, sig, _h = classical_ensemble('kerr', 0.20, hbar=hb, Ntraj=4000)
        l, r2, sp, _w = secular_rate(ts, sig); h = h_window(0.20, _w[0], _w[1])
        Fcl.append(l / h); R2cl.append(r2); SPcl.append(sp)
        print(f"   hbar={hb}: F_classical={l/h:.3f} R2={r2:.3f} spread={sp:.3f}")
    # quantum values recomputed here rather than hard-coded (reproducibility)
    Fq, R2q, SPq = [], [], []
    for hb in hbs:
        ts, sig, _h = run_gain('kerr', 0.20, hbar=hb, Twin=30.0, dt=1.5e-3, M=4096)
        l, r2, sp, _w = secular_rate(ts, sig); h = h_window(0.20, _w[0], _w[1])
        Fq.append(l / h); R2q.append(r2); SPq.append(sp)
        print(f"   hbar={hb}: F_quantum={l/h:.3f} R2={r2:.3f} spread={sp:.3f}")
    hbs=np.array(hbs); Fcl=np.array(Fcl); R2cl=np.array(R2cl); SPcl=np.array(SPcl)
    Fq=np.array(Fq); R2q=np.array(R2q); SPq=np.array(SPq)
    fig, ax = plt.subplots(figsize=(6.6, 5.0))
    ax.set_xscale('log'); ax.set_xlim(1.15, 0.052); ax.set_ylim(-0.08, 0.46)
    ct, ht = classical_tangent('harm', 0.20, Twin=200.0, tfit=40.0); Fref = ct / ht
    ax.axhline(Fref, ls='--', color='0.4', lw=1.1)
    ax.text(0.25, Fref + 0.015, f'classical reference $=${Fref:.3f}  ($\\pi/8$)',
            fontsize=8.6, color='0.4', ha='center')
    def draw(F, R2, SP, c, m, lab):
        ax.plot(hbs, F, m + '-', color=c, ms=7, lw=1.6, label=lab)
        bad = ~np.array([accepted(r, s_) for r, s_ in zip(R2, SP)])
        if bad.any(): ax.plot(hbs[bad], F[bad], m, color=c, ms=11, mfc='none', mew=1.8)
    draw(Fcl, R2cl, SPcl, '#2a7', 'o', 'classical ensemble (matched initial width)')
    draw(Fq, R2q, SPq, '#1f3b6e', 's', 'quantum (grid)')
    acc = np.array([accepted(a_,b_) and accepted(c_,d_)
                    for a_,b_,c_,d_ in zip(R2q,SPq,R2cl,SPcl)])
    ax.fill_between(hbs, Fq, Fcl, where=acc, color='#f4a', alpha=0.18, interpolate=True, label='quantum correction (accepted pts)')
    ax.set_xlabel(r'$\hbar_{\rm eff}$ (larger = broader initial width $\to$ classical)')
    ax.set_ylabel(r'$F=\lambda_{\rm param}/\langle h\rangle$ at fixed $\xi\simeq3$')
    ax.set_title('Classical ensemble vs quantum', fontsize=10.5)
    ax.grid(alpha=0.25, which='both')
    ax.legend(loc='upper left', fontsize=8.4, framealpha=0.92)
    fig.tight_layout(); fig.savefig('SM_fig4_classical_vs_quantum.png', dpi=160, bbox_inches='tight'); plt.close(fig)


if __name__ == "__main__":
    fig1_validation()
    fig2_no_collapse()
    fig3_crossover()
    fig4_classical_vs_quantum()
    print("done: SM_fig1..4 saved")
