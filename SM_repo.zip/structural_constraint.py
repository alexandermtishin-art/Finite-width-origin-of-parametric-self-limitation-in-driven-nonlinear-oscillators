"""
Structural constraint of the softening quartic model, and its removal.

Reproduces the numbers of Sec. IV D of the manuscript:

  * quartic well:      N_b * chi = 1/16 identically, for every beta and hbar_eff;
  * quartic + sextic:  the barrier condition gamma < beta^2/(4 Omega0^2) closes
                       the admissible range, and scanning all of it changes N_b
                       at fixed chi by a factor of only ~1.3;
  * two-harmonic well: the period k acts as an independent depth axis, and
                       N_b * chi spans 0.017 ... 0.111 at fixed |U|.
"""
import numpy as np
from SM_grid_engine import barrier_quartic_sextic, lattice_coeffs, lattice_barrier

U_ABS, OM0 = 1.0/24.0, 1.0

def quartic_identity():
    print('Quartic well: N_b * chi should equal 1/16 = 0.0625 for every (beta, hbar).')
    print(f"{'beta':>8} {'hbar_eff':>9} {'chi':>10} {'N_b':>10} {'N_b*chi':>9}")
    for beta in (0.05, 1/6., 0.5, 2.0):
        for hb in (0.01, 0.125, 1.0):
            Vb, _ = barrier_quartic_sextic(beta, 0.0, OM0)
            chi = hb*beta/4.0
            Nb = Vb/(hb*OM0)
            print(f'{beta:>8.4f} {hb:>9.3f} {chi:>10.5f} {Nb:>10.3f} {Nb*chi:>9.5f}')

def sextic_range(beta=1/6.):
    gmax = beta**2/(4*OM0**2)
    print(f'\nQuartic + sextic at beta = {beta:.4f}: barrier requires gamma < {gmax:.5f}.')
    print(f"{'gamma':>10} {'V_b':>10} {'V_b/V_b(0)':>11}")
    V0 = barrier_quartic_sextic(beta, 0.0, OM0)[0]
    for g in np.linspace(0.0, 0.999*gmax, 6):
        r = barrier_quartic_sextic(beta, g, OM0)
        if r is None:
            print(f'{g:>10.5f}  no barrier'); continue
        print(f'{g:>10.5f} {r[0]:>10.5f} {r[0]/V0:>11.3f}')
    print('  -> the achievable range of V_b at fixed chi is bounded; the degeneracy survives.')

def lattice_axis():
    print(f'\nTwo-harmonic well at |U| = 1/24: k is an independent depth axis.')
    print(f"{'k':>7} {'a':>10} {'b':>10} {'V_b':>10} {'N_b*chi':>9}")
    for k in (0.7, 1.0, 1.6, 2.5):
        a, b = lattice_coeffs(k, U_ABS, OM0)
        Vb, _ = lattice_barrier(k, U_ABS, OM0)
        print(f'{k:>7.2f} {a:>10.4f} {b:>10.4f} {Vb:>10.4f} {Vb*U_ABS:>9.4f}')
    print('  -> compare with the constant 1/16 = 0.0625 of the quartic well.')

if __name__ == '__main__':
    quartic_identity(); sextic_range(); lattice_axis()
