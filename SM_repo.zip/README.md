# Finite-width origin of parametric self-limitation in driven nonlinear oscillators

Supplementary code for the manuscript *"Finite-width origin of parametric self-limitation
in driven nonlinear oscillators"* (A. M. Tishin).

The code provides a **validated, truncation-free** numerical study of the parametric gain
of a driven nonlinear oscillator and its **width crossover**, and compares the quantum
result against a **matched-width classical (truncated-Wigner) ensemble**.

---

## Files

| File | Contents |
|------|----------|
| `SM_grid_engine.py` | Grid split-operator engine: grid construction, imaginary-time ground state, split-operator time evolution with effective ℏ, covariance-top-eigenvalue observable, pre-registered secular-rate extractor, classical-tangent reference, and the classical truncated-Wigner ensemble benchmark. Runs a self-test — including both classical controls — when executed directly. |
| `SM_reproduce_figures.py` | Reproduces Figs. 1–4 of the manuscript by calling the engine. |
| `structural_constraint.py` | Reproduces the numbers of Sec. IV D: the identity `N_b*chi = 1/16`, the bounded sextic range, and the two-harmonic depth axis. Run directly. |

## Requirements

- Python 3.11
- numpy ≥ 1.24
- matplotlib ≥ 3.7 (for the figure-reproduction script only)

```bash
pip install "numpy>=1.24" "matplotlib>=3.7"
```

## Usage

**Self-test the engine** (harmonic validation plus both classical controls):

```bash
python SM_grid_engine.py
```

Expected output (machine-independent):

```
harmonic ground energy = 0.5 (expect 0.5)
A=0.08: gain=0.0200  (Mathieu A/4=0.0200)  R2=1.000
A=0.16: gain=0.0399  (Mathieu A/4=0.0400)  R2=1.000
classical tangent control (harmonic, must equal pi/8 = 0.3927):
  Twin=200 tfit=40  rate=0.0499 (A/4=0.0500)  F=0.3925
classical ensemble control (harmonic, must equal quantum Mathieu):
  hbar=1.0: F_ens=0.394  (expect A/4/h=0.394)  R2=1.000
  hbar=0.25: F_ens=0.394  (expect A/4/h=0.394)  R2=1.000
classical ensemble, Kerr (finite-width crossover):
  hbar=1.0: F_ens=0.030  R2=0.427
  hbar=0.25: F_ens=0.331  R2=0.997
  hbar=0.06: F_ens=0.376  R2=1.000
```

**Reproduce all figures** (writes `SM_fig1..4_*.png`; runtime ≈ several minutes):

```bash
python SM_reproduce_figures.py
```

## Analytic normalisation

For `Omega^2(t) = Omega0^2 (1 + A cos 2 Omega0 t)` one has `Omega dOmega/dt = -A Omega0^2
sin 2 Omega0 t` exactly, so that

```
h(t) = eta(t) Omega(t) = |dOmega/dt| Omega / Omega0^2 = A Omega0 |sin 2 Omega0 t|
```

with no corrections in `A`. With `<h>` taken as the **time average over the fit window**,
`<h> = (2/pi) A Omega0`, and with the Mathieu rate `lambda = A Omega0 / 4`:

```
F_harm = (A/4) / (2A/pi) = pi/8 = 0.392699
```

independent of the drive amplitude and of `hbar_eff`. Had `<h>` been defined as the root
mean square of `h` over the same window, the identical construction would give
`1/sqrt(8) = 0.353553`, lower by the factor `pi*sqrt(2)/4 = 1.111`. The time-average
convention is used throughout, for both the quantum and the classical branch, on the same
window.

## Figures

| Figure | What it shows |
|--------|----------------|
| Fig. 1 | Engine validation: extracted parametric gain reproduces the analytic Mathieu rate `A/4` to <1% (R²=1.00). |
| Fig. 2 | Quantum parametric gain `F = lambda/<h>` vs `xi = eta/|U|` at `hbar_eff=1` for four platforms. |
| Fig. 3 | Width (quantum-to-classical) crossover of the confining gain at fixed `(|U|, xi)`, against the classical reference `pi/8`. |
| Fig. 4 | Classical ensemble vs quantum at matched initial width. |

## Method (summary)

The dynamics are integrated on a position grid with a symmetric (Strang) split-operator
propagator using the FFT — unitary, unconditionally stable, and free of the Fock-basis
truncation instabilities of strongly anharmonic driven Hamiltonians. The instability rate
is the parametric gain, defined as the secular exponential growth rate of the largest
covariance-matrix eigenvalue, accepted only under pre-registered criteria (log-linearity
R² ≥ 0.98, window-independence ≤ 10%, separation from saturation, and grid/step
convergence). Quantumness is tuned by an effective ℏ; the matched-width classical ensemble
and the classical tangent rate provide the references against which the quantum result is
compared. The two classical estimators must coincide in the harmonic limit, and they do, both returning `pi/8`.

## Reproducibility

`SM_grid_engine.py` exposes `__version__ = "1.0"` and a fixed `RANDOM_SEED = 0`. The
classical ensemble is convergent in trajectory number (<1% for N ≥ 2000) and stable across
random seeds (standard deviation ≈ 0.004). Rate extraction depends on the fit window; the
window used for each reported rate is stated in the code, and the tangent reference
requires `Twin >= 100` with `tfit >= 0.2*Twin`.

## Structural note on the softening model

For `V(x) = 1/2 Omega0^2 x^2 - (beta/4) x^4` the barrier height is `V_b = Omega0^2/(16|U|)`,
so the number of quanta below the barrier obeys

```
N_b = V_b / (hbar_eff Omega0) = 1/(16 chi),     i.e.   N_b * chi = 1/16
```

identically. Once `m` and `Omega0` are fixed the potential retains a single independent
shape parameter, so the well depth and the crossover parameter are not independent axes:
the accessible parameter space is a curve, not a plane, and no scan over `beta` and
`hbar_eff` within this model can separate internal amplification from over-barrier escape.

**Adding the next term of the expansion does not help.** For
`V = 1/2 Omega0^2 x^2 - (beta/4) x^4 + (gamma/6) x^6` the barrier exists only while the two
positive roots of `gamma u^2 - beta u + Omega0^2 = 0` in `u = x^2` remain distinct, i.e. for
`gamma < beta^2/(4 Omega0^2)`; at the bound they merge and the barrier disappears. The
admissible range of `gamma` is closed, and scanning all of it changes `N_b` at fixed `chi`
by a factor of only 1.3. Use `barrier_quartic_sextic(beta, gamma)` to check this.

**A change of potential class is required.** The two-harmonic well
`V0(x) = a[1 - cos kx] + b[1 - cos 2kx]`, with `a` and `b` solved from
`k^2(a+4b) = Omega0^2` and `k^4(a+16b)/24 = |U| Omega0^2`, leaves the period `k` free as an
independent depth axis:

| `k` | `V_b` | `N_b * chi` |
|---|---|---|
| 0.7 | 2.666 | 0.111 |
| 1.0 | 2.000 | 0.083 |
| 1.6 | 0.940 | 0.039 |
| 2.5 | 0.410 | 0.017 |

against the constant `1/16 = 0.0625` of the quartic well. Use `lattice_coeffs(k, U)` and
`lattice_barrier(k, U)`.

**Scope.** This constraint concerns the statically defined softening quartic well under
frequency modulation, where the barrier is a property of the potential. It does not apply
to driven bistable or Kerr-parametric descriptions in which the pump reshapes the effective
quasienergy landscape and the barrier is dynamical.

## License

MIT.
