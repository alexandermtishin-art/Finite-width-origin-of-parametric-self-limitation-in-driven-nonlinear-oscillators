"""
Supplemental Material — Code 1 of 2
===================================================================
Grid split-operator engine for the quantum parametric gain of a
driven nonlinear oscillator.

Companion to: "Quantum-to-classical crossover of geometric self-limitation
in parametrically driven nonlinear oscillators" (A. M. Tishin).

This module provides a validated, Fock-truncation-free computation of the
parametric-amplification rate of a driven anharmonic oscillator, together
with an effective-hbar knob for the quantum-to-classical crossover.

Physical model (hbar_eff form):
    i * hbar_eff * d_t psi = [ -hbar_eff^2/2 * d_xx + V(x,t) ] psi
    V(x,t) = 1/2 * Omega^2(t) * x^2  +  V_nl(x)
    Omega^2(t) = Omega0^2 * (1 + A cos(omega_p t)),  omega_p = 2 Omega0
Nonlinear part V_nl:
    'harm'      : 0                      (linear reference -> Mathieu)
    'kerr'      : +(beta/4) x^4          (confining / hardening)
    'hard'      : +(beta/4) x^4 + c6 x^6 (steeper confining)
    'transmon'  : -Omega^2(t) cos(x)     (cosine well; softening + escape)
Anharmonicity normalization:  |U| = |quartic coefficient| / Omega0^2 = beta/4.

Observable:
    Parametric gain = secular exponential growth rate of the largest
    eigenvalue of the single-mode covariance matrix
        C = [[Var_x, Cov_xp], [Cov_xp, Var_p]]
    computed from the evolving state on the grid. This is the quantum
    counterpart of the largest classical tangent-space stretching, and it
    equals the analytic Mathieu rate A/4 in the harmonic case (validation).

Requirements: numpy. (matplotlib only for the figure-reproduction script.)
Author-reviewed; AI tools assisted implementation.

Environment (tested): Python 3.11; numpy >= 1.24.
(For the figure-reproduction script: matplotlib >= 3.7.)
===================================================================
"""

import numpy as np

__version__ = "1.0"
RANDOM_SEED = 0   # no stochastic components at present; fixed for reproducibility/future-proofing

# ---------------------------------------------------------------- grid
def make_grid(L=24.0, M=4096):
    """Uniform periodic position grid on [-L, L) with FFT wavenumbers."""
    x = np.linspace(-L, L, M, endpoint=False)
    dx = x[1] - x[0]
    k = 2 * np.pi * np.fft.fftfreq(M, d=dx)
    return x, dx, k

# ---------------------------------------------------- static potential
def potential(kind, x, O2, beta, c6=0.0):
    """Static potential V(x) for a given instantaneous Omega^2 = O2."""
    if kind == 'harm':
        return 0.5 * O2 * x**2
    if kind == 'kerr':
        return 0.5 * O2 * x**2 + (beta / 4.0) * x**4
    if kind == 'hard':
        return 0.5 * O2 * x**2 + (beta / 4.0) * x**4 + c6 * x**6
    if kind == 'transmon':
        return -O2 * np.cos(x)          # cosine well (softening + escape)
    raise ValueError(kind)

# ---------------------------------------------------- ground state (it)
def ground_state(x, dx, k, V, hbar=1.0, dtau=None, steps=6000):
    """Lowest eigenstate of H = -hbar^2/2 d_xx + V via imaginary-time propagation."""
    if dtau is None:
        dtau = 0.2 * hbar
    psi = np.exp(-x**2 / (2 * max(hbar, 1e-6))).astype(complex)
    psi /= np.sqrt(np.sum(np.abs(psi)**2) * dx)
    eK = np.exp(-0.5 * hbar**2 * k**2 * dtau)
    eV = np.exp(-V * dtau / 2)
    for _ in range(steps):
        psi = eV * psi
        psi = np.fft.ifft(eK * np.fft.fft(psi))
        psi = eV * psi
        psi /= np.sqrt(np.sum(np.abs(psi)**2) * dx)
    return psi

def ground_energy(x, dx, k, V, psi, hbar=1.0):
    T = np.sum(np.conj(psi) * np.fft.ifft(0.5 * hbar**2 * k**2 * np.fft.fft(psi))).real * dx
    return T + np.sum(np.abs(psi)**2 * V).real * dx

# ---------------------------------------------------- covariance top ev
def covariance_top_eigenvalue(x, dx, k, psi, hbar=1.0):
    """Largest eigenvalue of the 2x2 covariance matrix of |psi>.

    The canonical momentum of  i hbar d_t psi = [-hbar^2/2 d_xx + V] psi  is
    p = -i hbar d_x, so the momentum moments carry explicit factors of hbar."""
    d = np.abs(psi)**2
    n = np.sum(d) * dx
    d = d / n
    ex = np.sum(d * x) * dx
    ex2 = np.sum(d * x**2) * dx
    phik = np.fft.fft(psi)
    Np = np.sum(np.abs(phik)**2)
    ep = hbar * np.sum(np.conj(phik) * k * phik).real / Np
    ep2 = hbar**2 * np.sum(np.conj(phik) * k**2 * phik).real / Np
    p_psi = np.fft.ifft(hbar * k * np.fft.fft(psi))  # (-i hbar d/dx) psi
    exp_xp = np.sum(np.conj(psi) * x * p_psi).real * dx / n
    Vx = ex2 - ex * ex
    Vp = ep2 - ep * ep
    Cxp = exp_xp - ex * ep
    return 0.5 * (Vx + Vp) + np.sqrt(max(0.25 * (Vx - Vp)**2 + Cxp**2, 0.0))

# ---------------------------------------------------- driving helpers
def _Om(t, A, wp, O0=1.0):
    return np.sqrt(max(O0**2 * (1 + A * np.cos(wp * t)), 1e-12))

def _eta(t, A, wp, O0=1.0, omega=1.0):
    return abs((-O0**2 * A * wp * np.sin(wp * t)) / (2 * _Om(t, A, wp, O0))) / omega**2

def h_window(A, t0, t1, wp=2.0, O0=1.0, n=200001):
    """Time average of h(t) = eta(t) Omega(t) over the fit window [t0, t1]."""
    t = np.linspace(t0, t1, n)
    h = np.array([_eta(u, A, wp, O0) * _Om(u, A, wp, O0) for u in t])
    return np.trapezoid(h, t) / (t1 - t0)


def eta_char(A, wp=2.0):
    """Period-averaged eta = <|dOmega/dt|/omega^2>, omega = Omega0 = 1."""
    ts = np.linspace(0, 2 * np.pi / wp, 400)
    return np.mean([_eta(t, A, wp) for t in ts])

# ---------------------------------------------------- time evolution
def run_gain(kind, A, hbar=1.0, beta=1.0/6.0, c6=0.02,
             L=24.0, M=4096, Twin=30.0, dt=2e-3, rec=8, wp=2.0, O0=1.0):
    """
    Evolve the ground state under the parametric drive and return
    (times, covariance-top-eigenvalue trajectory, window-averaged h),
    where h(t) = eta(t) * Omega(t).
    """
    x, dx, k = make_grid(L, M)
    psi = ground_state(x, dx, k, potential(kind, x, O0**2, beta, c6), hbar)
    eK = np.exp(-1j * hbar * 0.5 * k**2 * dt)
    n = int(Twin / dt)
    ts, sig = [], []
    h_int = 0.0
    for i in range(n):
        t = i * dt
        O2 = O0**2 * (1 + A * np.cos(wp * t))
        V = potential(kind, x, O2, beta, c6)
        hV = np.exp(-1j * V / hbar * dt / 2)
        psi = hV * psi
        psi = np.fft.ifft(eK * np.fft.fft(psi))
        psi = hV * psi
        h_int += _eta(t, A, wp, O0) * _Om(t, A, wp, O0) * dt
        if i % rec == 0:
            ts.append(t)
            sig.append(covariance_top_eigenvalue(x, dx, k, psi, hbar))
    return np.array(ts), np.array(sig), h_int / Twin

# ------------------------------------ pre-registered secular-rate fit
def secular_rate(ts, sig, tmin=2.0, sat_frac=0.6):
    """
    Parametric gain = (1/2) * secular slope of ln(sigma_max), extracted by a
    period-averaged linear fit over the exponential window, returning
    (lambda, R2, window_spread, (t_start, t_end)).

    Pre-registered acceptance (applied by the caller):
      accept only if R2 >= 0.98 AND window_spread <= 0.10, on a window that
      is separated from saturation (sig <= sat_frac * max).
    """
    dts = ts[1] - ts[0]
    win = max(3, int(np.pi / dts))               # one drive period (period = pi)
    sm = np.convolve(sig, np.ones(win) / win, mode='valid')
    tsm = ts[win - 1:]
    ln = np.log(np.clip(sm, 1e-300, None))
    smax = sm.max()
    lo = np.argmax(tsm >= tmin)
    # W3: the window ends BEFORE sigma first reaches sat_frac of its maximum.
    cross = np.where(sm[lo:] > sat_frac * smax)[0]
    hi = lo + cross[0] if len(cross) else len(tsm) - 1
    if hi - lo < 12:
        return np.nan, np.nan, np.nan, (np.nan, np.nan)
    t = tsm[lo:hi]; y = ln[lo:hi]
    Amat = np.vstack([t, np.ones(len(t))]).T
    sl, ic = np.linalg.lstsq(Amat, y, rcond=None)[0]
    yhat = sl * t + ic
    r2 = 1 - np.sum((y - yhat)**2) / np.sum((y - y.mean())**2)
    n = len(t)
    s1 = np.linalg.lstsq(np.vstack([t[:n//2], np.ones(n//2)]).T, y[:n//2], rcond=None)[0][0]
    s3 = np.linalg.lstsq(np.vstack([t[n//2:], np.ones(n-n//2)]).T, y[n//2:], rcond=None)[0][0]
    spread = abs(s1 - s3) / abs(0.5 * (s1 + s3)) if (s1 + s3) != 0 else np.inf
    return sl / 2, r2, spread, (t[0], t[-1])

# ------------------------------------ classical tangent reference
def classical_tangent(kind, A, beta=1.0/6.0, Twin=30.0, dt=1e-3, wp=2.0, c6=0.02, tfit=2.0):
    """Classical finite-time tangent-stretching rate for the same driven oscillator
    (used as the hbar->0 reference); returns (rate, window-averaged h)."""
    y = np.array([0.02, 0.0, 1.0, 0.0]); nr = np.hypot(y[2], y[3]); y[2]/=nr; y[3]/=nr
    def f(t, y):
        q, p, dq, dp = y
        O2 = 1 + A * np.cos(wp * t)
        if kind == 'transmon':
            fp = -O2 * np.sin(q); jpq = -O2 * np.cos(q)
        elif kind == 'harm':
            fp = -O2 * q;                jpq = -O2
        elif kind == 'hard':
            fp = -O2*q - beta*q**3 - 6.0*c6*q**5
            jpq = -O2 - 3*beta*q**2 - 30.0*c6*q**4
        else:
            fp = -O2 * q - beta * q**3; jpq = -O2 - 3 * beta * q**2
        return np.array([p, fp, dp, jpq * dq])
    n = int(Twin / dt); t = 0.0; logs = 0.0; hint = 0.0; ts = []; st = []
    for i in range(n):
        k1 = f(t, y); k2 = f(t+dt/2, y+dt/2*k1); k3 = f(t+dt/2, y+dt/2*k2); k4 = f(t+dt, y+dt*k3)
        y = y + dt/6*(k1+2*k2+2*k3+k4); t += dt
        hint += _eta(t, A, wp) * _Om(t, A, wp) * dt
        nr = np.hypot(y[2], y[3])
        if i % 20 == 0 and nr > 0:
            logs += np.log(nr); y[2] /= nr; y[3] /= nr; ts.append(t); st.append(logs)
    ts = np.array(ts); st = np.array(st)
    m = ts > tfit
    sl = np.linalg.lstsq(np.vstack([ts[m], np.ones(m.sum())]).T, st[m], rcond=None)[0][0]
    tt=np.linspace(tfit,Twin,200001)
    hw=np.trapezoid([_eta(u,A,wp)*_Om(u,A,wp) for u in tt],tt)/(Twin-tfit)
    return sl, hw

# ------------------------------------ classical (truncated-Wigner) ensemble
def classical_ensemble(kind, A, hbar=1.0, beta=1.0/6.0, c6=0.02, Ntraj=4000, seed=0,
                       Twin=30.0, dt=2e-3, rec=8, wp=2.0, O0=1.0):
    """
    Truncated-Wigner (classical ensemble) benchmark. Evolve Ntraj classical
    trajectories whose initial phase-space distribution is Gaussian with width
    matched to the quantum vacuum (Var_x = Var_p = hbar/2), under the SAME drive,
    and return (times, covariance-top-eigenvalue trajectory, window-averaged h).

    Purpose: separate the CLASSICAL finite-initial-width contribution to the
    self-limitation from the genuine QUANTUM correction. Fit the returned sigma
    with secular_rate exactly as for the quantum gain, and compare F.

    Control (validation): for kind='harm' the ensemble reproduces the analytic
    Mathieu rate A/4 for ANY hbar (linear system) -> validates the observable.
    Convergence: F is stable in Ntraj (<~1% for Ntraj>=2000) and across seeds
    (std ~ 0.004 at Ntraj=3000); see the self-test.
    """
    rng = np.random.default_rng(seed)
    var = hbar / 2.0
    x = rng.normal(0.0, np.sqrt(var), Ntraj)
    p = rng.normal(0.0, np.sqrt(var), Ntraj)
    def force(x, t):
        O2 = O0**2 * (1.0 + A * np.cos(wp * t))
        if kind == 'harm':     return -O2 * x
        if kind == 'kerr':     return -O2 * x - beta * x**3
        if kind == 'hard':     return -O2 * x - beta * x**3 - 6.0 * c6 * x**5
        if kind == 'transmon': return -O2 * np.sin(x)
        raise ValueError(kind)
    n = int(Twin / dt); ts = []; sig = []; h_int = 0.0
    for i in range(n):
        t = i * dt
        k1x, k1p = p, force(x, t)
        k2x, k2p = p + dt/2*k1p, force(x + dt/2*k1x, t + dt/2)
        k3x, k3p = p + dt/2*k2p, force(x + dt/2*k2x, t + dt/2)
        k4x, k4p = p + dt*k3p,   force(x + dt*k3x,   t + dt)
        x = x + dt/6 * (k1x + 2*k2x + 2*k3x + k4x)
        p = p + dt/6 * (k1p + 2*k2p + 2*k3p + k4p)
        h_int += _eta(t, A, wp, O0) * _Om(t, A, wp, O0) * dt
        if i % rec == 0:
            Vx = np.var(x); Vp = np.var(p); Cxp = np.mean(x*p) - np.mean(x)*np.mean(p)
            sig.append(0.5*(Vx+Vp) + np.sqrt(max(0.25*(Vx-Vp)**2 + Cxp**2, 0.0)))
            ts.append(t)
    return np.array(ts), np.array(sig), h_int / Twin

if __name__ == "__main__":
    # quick self-test: harmonic validation
    x, dx, k = make_grid(24.0, 4096)
    ps = ground_state(x, dx, k, 0.5 * x**2, 1.0)
    print("harmonic ground energy =", round(ground_energy(x, dx, k, 0.5*x**2, ps, 1.0), 4), "(expect 0.5)")
    for A in [0.08, 0.16]:
        ts, sig, h = run_gain('harm', A)
        lam, r2, _, _w = secular_rate(ts, sig)
        print(f"A={A}: gain={lam:.4f}  (Mathieu A/4={A/4:.4f})  R2={r2:.3f}")
    # tangent-estimator control: MUST agree with the ensemble and with pi/8
    print("classical tangent control (harmonic, must equal pi/8 = 0.3927):")
    c, h = classical_tangent('harm', 0.20, Twin=200.0, tfit=40.0)
    print(f"  Twin=200 tfit=40  rate={c:.4f} (A/4=0.0500)  F={c/h:.4f}")
    # classical-ensemble control: harmonic must give F = A/4 / h for any hbar
    print("classical ensemble control (harmonic, must equal quantum Mathieu):")
    for hb in [1.0, 0.25]:
        ts, sig, _ = classical_ensemble('harm', 0.20, hbar=hb)
        lam, r2, _, w = secular_rate(ts, sig)
        h = h_window(0.20, w[0], w[1])
        print(f"  hbar={hb}: F_ens={lam/h:.3f}  (expect A/4/h={0.05/h:.3f})  R2={r2:.3f}")
    print("classical ensemble, Kerr (finite-width crossover):")
    for hb in [1.0, 0.25, 0.06]:
        ts, sig, _ = classical_ensemble('kerr', 0.20, hbar=hb)
        lam, r2, _, w = secular_rate(ts, sig)
        h = h_window(0.20, w[0], w[1])
        print(f"  hbar={hb}: F_ens={lam/h:.3f}  R2={r2:.3f}")
